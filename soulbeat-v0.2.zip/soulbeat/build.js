// Assembles index.html from the files in src/. Run: node build.js
const fs = require('fs');
const r = (f) => fs.readFileSync('src/' + f, 'utf8');
const js = [r('engine.js'), 'window.SB_RUNTIME_LUA = ' + JSON.stringify(r('runtime.lua')) + ';', r('export.js'), r('i18n_auto.js'), r('i18n_extra.js'), r('app1.js'), r('app2.js'), r('app3.js')].join('\n;\n');
fs.writeFileSync('index.html', r('index.html').replace('/*__JS__*/', () => js));
console.log('index.html built:', fs.statSync('index.html').size, 'bytes');
