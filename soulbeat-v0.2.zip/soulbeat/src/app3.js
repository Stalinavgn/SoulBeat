// ===== SoulBeat app, part 3: music, storage, export, video, keys, init =====
// ---------- storage ----------
let dbP = null;
function db() {
  if (!dbP) dbP = new Promise((res, rej) => { const r = indexedDB.open('soulbeat', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  return dbP;
}
async function idbPut(k, v) { try { const d = await db(); await new Promise((res, rej) => { const t = d.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); t.oncomplete = res; t.onerror = () => rej(t.error); }); } catch (e) { } }
async function idbGet(k) { try { const d = await db(); return await new Promise((res) => { const r = d.transaction('kv').objectStore('kv').get(k); r.onsuccess = () => res(r.result); r.onerror = () => res(undefined); }); } catch (e) { return undefined; } }
function saveLocal() { idbPut('proj', proj); }

// ---------- music ----------
function makePeaks(buf) {
  const d = buf.getChannelData(0), hop = Math.floor(buf.sampleRate / 100), n = Math.floor(d.length / hop), p = new Float32Array(n);
  let mx = 0.0001;
  for (let i = 0; i < n; i++) { let m = 0; for (let j = i * hop, e = j + hop; j < e; j += 4) { const v = d[j] < 0 ? -d[j] : d[j]; if (v > m) m = v; } p[i] = m; if (m > mx) mx = m; }
  for (let i = 0; i < n; i++) p[i] /= mx;
  return p;
}
function detectBpm(buf) {
  const d = buf.getChannelData(0), R = 200, hop = Math.floor(buf.sampleRate / R), n = Math.min(Math.floor(d.length / hop), R * 150);
  const env = new Float32Array(n);
  for (let i = 0; i < n; i++) { let s = 0; for (let j = i * hop, e = j + hop; j < e; j += 2) s += d[j] * d[j]; env[i] = Math.sqrt(s / (hop / 2)); }
  const on = new Float32Array(n); let mean = 0;
  for (let i = 1; i < n; i++) { const v = env[i] - env[i - 1]; on[i] = v > 0 ? v : 0; mean += on[i]; }
  mean /= n; for (let i = 0; i < n; i++) on[i] = Math.max(0, on[i] - mean * 0.5);
  const score = (bpm) => { const lag = (R * 60) / bpm; let s = 0; for (let i = 0; i + 2 * lag + 1 < n; i += 1) { const a = i + lag, a0 = a | 0, f = a - a0, b = i + 2 * lag, b0 = b | 0, f2 = b - b0; s += on[i] * ((on[a0] * (1 - f) + on[a0 + 1] * f) + 0.5 * (on[b0] * (1 - f2) + on[b0 + 1] * f2)); } return s; };
  let best = 120, bs = -1;
  for (let b = 70; b <= 180; b += 0.5) { const s = score(b); if (s > bs) { bs = s; best = b; } }
  for (let b = best - 0.5; b <= best + 0.5; b += 0.02) { const s = score(b); if (s > bs) { bs = s; best = b; } }
  if (Math.abs(best - Math.round(best)) < 0.4) best = Math.round(best);
  const lag = (R * 60) / best; let bp = 0, bps = -1;
  for (let p = 0; p < lag; p++) { let s = 0; for (let k = 0; p + k * lag < n; k++) s += on[Math.round(p + k * lag)] || 0; if (s > bps) { bps = s; bp = p; } }
  return { bpm: Math.round(best * 100) / 100, offset: Math.round((bp / R) * 1000) / 1000 };
}
async function setMusic(blob, name, fresh) {
  try {
    toast(tr('Reading the track…'), 20000);
    const buf = await ensureAudio().decodeAudioData(await blob.arrayBuffer());
    pause(); music.buf = buf; music.name = name; music.blob = blob; music.peaks = makePeaks(buf);
    if (fresh) {
      pushUndo(); proj.duration = Math.round(buf.duration * 100) / 100;
      const r = detectBpm(buf); proj.bpm = r.bpm; proj.offset = r.offset;
      idbPut('music', { name, blob });
      toast(tr('Track loaded. Tempo: ') + r.bpm + tr(' BPM — if the grid misses the beats, fix BPM or “1st beat”'), 6000);
    } else toast(tr('Track loaded'), 1200);
    syncTop(); seek(0); changed(true);
  } catch (e) { toast(tr('Could not read this audio file. Try mp3, wav or ogg'), 5000); }
}
let taps = [];
$('bTap').onclick = () => {
  const now = performance.now(); if (taps.length && now - taps[taps.length - 1] > 2200) taps = [];
  taps.push(now);
  if (taps.length >= 4) { const iv = (taps[taps.length - 1] - taps[0]) / (taps.length - 1); pushUndo('bpm'); proj.bpm = Math.round(60000 / iv * 10) / 10; syncTop(); changed(true); }
  $('bTap').textContent = taps.length < 4 ? tr('Tap ') + taps.length : tr('Tap ✓');
};
$('bAuto').onclick = () => { if (!music.buf) return toast(tr('Load a track first')); pushUndo(); const r = detectBpm(music.buf); proj.bpm = r.bpm; proj.offset = r.offset; syncTop(); changed(true); toast(tr('Tempo: ') + r.bpm + ' BPM'); };
$('iBpm').onchange = (e) => { const v = +e.target.value; if (v >= 30 && v <= 400) { pushUndo(); proj.bpm = v; changed(true); } syncTop(); };
$('iOff').onchange = (e) => { pushUndo(); proj.offset = Math.max(0, +e.target.value || 0); changed(true); syncTop(); };
$('iSnap').onchange = drawTl;
$('bMusic').onclick = () => $('fMusic').click();
$('fMusic').onchange = (e) => { const f = e.target.files[0]; if (f) setMusic(f, f.name, true); e.target.value = ''; };
$('fAssets').onchange = async (e) => { await takeFiles([...e.target.files], true); e.target.value = ''; };
$('bEnemy').onclick = () => $('fEnemy').click();
$('fEnemy').onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try { const a = await addAssetFile(fixType(f)); renderAssets(); setEnemy(a.id); }
  catch (err) { toast(tr('Could not read: ') + f.name, 5000); }
};
function fixType(f) {
  if (f.type) return f;
  const ext = f.name.toLowerCase().split('.').pop(), m = { mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4', flac: 'audio/flac', gif: 'image/gif', png: 'image/png', webp: 'image/webp' }[ext];
  return m ? new File([f], f.name, { type: m }) : f;
}
async function takeFiles(files, assetsOnly) {
  let added = 0; const failed = [];
  for (const f of files) {
    const nm = f.name.toLowerCase();
    if (nm.endsWith('.json') || nm.endsWith('.soulbeat')) { await openProjectFile(f); return; }
    const isAudio = f.type.startsWith('audio') || /\.(mp3|wav|ogg|m4a|flac)$/.test(nm), isImg = f.type.startsWith('image'), isVid = f.type.startsWith('video') || /\.(mp4|webm|mov|m4v)$/.test(nm);
    if (isAudio && !assetsOnly && (f.size > 900000 || !music.buf)) { await setMusic(f, f.name, true); continue; }
    if (isAudio || isImg || isVid) { try { const a = await addAssetFile(fixType(f)); added++; if (a.kind === 'anim' && !proj.settings.monsterAsset) proj.settings.monsterAsset = a.id; } catch (err) { failed.push(f.name); } }
  }
  if (failed.length) toast(tr('Could not read: ') + failed.join(', '), 5000);
  if (added) { $('tabAssets').click(); renderAssets(); changed(true); toast(tr('Files added: ') + added); }
}
let dragDepth = 0;
window.addEventListener('dragenter', (e) => { if (e.dataTransfer.types.includes('Files')) { dragDepth++; $('dropveil').style.display = 'flex'; } });
window.addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; $('dropveil').style.display = 'none'; } });
window.addEventListener('dragover', (e) => { if (e.dataTransfer.types.includes('Files')) e.preventDefault(); });
window.addEventListener('drop', (e) => { dragDepth = 0; $('dropveil').style.display = 'none'; if (e.dataTransfer.files.length) { e.preventDefault(); takeFiles([...e.dataTransfer.files], false); } });

// ---------- project files ----------
const blobToDataURL = (b) => new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(b); });
function download(blob, name) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 30000); }
const TRL = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
const safeName = (s) => (String(s).replace(/[а-яё]/gi, (c) => { const l = c.toLowerCase(), t = TRL[l] || ''; return l === c ? t : t.charAt(0).toUpperCase() + t.slice(1); }).replace(/[^A-Za-z0-9 _-]/g, '').trim().slice(0, 40) || 'Fight');
async function saveProjectFile() {
  const o = { app: 'soulbeat', proj, music: music.blob ? { name: music.name, data: await blobToDataURL(music.blob) } : null };
  download(new Blob([JSON.stringify(o)], { type: 'application/json' }), (proj.name.replace(/[\\/:*?"<>|]/g, '').trim() || 'project') + '.soulbeat.json'); toast(tr('Project saved to a file'));
}
async function loadProject(p, mus) {
  pause(); proj = Object.assign(newProject(), p); proj.settings = Object.assign(newProject().settings, p.settings || {});
  sel.clear(); undoSt.length = 0; redoSt.length = 0; curT = 0;
  for (const k in imgEl) delete imgEl[k]; for (const k in sndBuf) delete sndBuf[k]; for (const k in animFr) delete animFr[k];
  await Promise.all(proj.assets.map(loadAssetMedia));
  music.buf = null; music.name = ''; music.blob = null; music.peaks = null;
  rebake(); resetPlayer();
  if (mus) await setMusic(mus.blob, mus.name, false);
  syncTop(); renderAssets(); changed(true); seek(0);
}
async function openProjectFile(f) {
  try {
    const o = JSON.parse(await f.text()); if (o.app !== 'soulbeat' || !o.proj) throw 0;
    let mus = null; if (o.music) { mus = { name: o.music.name, blob: await (await fetch(o.music.data)).blob() }; idbPut('music', mus); } else idbPut('music', null);
    await loadProject(o.proj, mus); toast(tr('Project opened'));
  } catch (e) { toast(tr('This does not look like a SoulBeat project file'), 4000); }
}
$('fProj').onchange = (e) => { const f = e.target.files[0]; if (f) openProjectFile(f); e.target.value = ''; };
$('bProj').onclick = () => {
  modal(tr('<h2>PROJECT</h2><p>Your work is saved automatically in this browser. A project file is for making a copy, moving to another computer or keeping several fights. Music and assets are stored inside the file.</p><div class="acts"><button class="btn big pri" id="mSave">💾 Save to file</button><button class="btn big" id="mOpen">📂 Open file</button><button class="btn big" id="mDemo">Demo fight</button><button class="btn big" id="mNew">New empty</button><button class="btn big" id="mClose">Close</button></div>'));
  $('mSave').onclick = () => { saveProjectFile(); closeModal(); };
  $('mOpen').onclick = () => { closeModal(); $('fProj').click(); };
  $('mDemo').onclick = () => { if (confirm(tr('Replace the current fight with the demo? You can save the current one to a file first.'))) { idbPut('music', null); loadProject(demoProject(), null); closeModal(); } };
  $('mNew').onclick = () => { if (confirm(tr('Start from scratch? You can save the current fight to a file first.'))) { idbPut('music', null); loadProject(newProject(), null); closeModal(); } };
  $('mClose').onclick = closeModal;
};

// ---------- export to Create Your Frisk ----------
const cvBytes = (c) => new Promise((res) => c.toBlob(async (b) => res(new Uint8Array(await b.arrayBuffer())), 'image/png'));
const dataURLBytes = async (u) => new Uint8Array(await (await fetch(u)).arrayBuffer());
async function buildMod() {
  rebake();
  const st = proj.settings, enc = new TextEncoder(), files = [], nm = safeName(proj.name);
  const useTake = st.cyfReplay && proj.replay && proj.replay.d.length > 60;
  files.push({ path: 'Lua/Encounters/' + nm + '.lua', data: enc.encode(SBX.genEncounter(proj)) });
  files.push({ path: 'Lua/Monsters/ub_monster.lua', data: enc.encode(SBX.genMonster(proj)) });
  const EG = enemyGfx(); let enemy = null;
  if (EG) {
    for (let i = 0; i < EG.frames.length; i++) files.push({ path: 'Sprites/ub/enemy/' + (i + 1) + '.png', data: await cvBytes(EG.frames[i]) });
    enemy = { n: EG.frames.length, fps: EG.fps, w: EG.frames[0].width, h: EG.frames[0].height, s: st.monsterScale || 1, x: st.monsterX || 0, y: st.monsterY || 0 };
  }
  files.push({ path: 'Lua/Waves/ub_wave.lua', data: enc.encode(SBX.genWave(B, proj, { hasMusic: !!music.buf, replay: useTake ? proj.replay : null, enemy })) });
  for (const s of B.sprites) files.push({ path: 'Sprites/ub/' + s + '.png', data: await cvBytes(getSprite(s)) });
  if (st.waitZ) {
    const c = document.createElement('canvas'); c.width = 260; c.height = 30; const x = c.getContext('2d');
    x.font = 'bold 22px Consolas, monospace'; x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('[ PRESS Z ]', 130, 16);
    files.push({ path: 'Sprites/ub/pressz.png', data: await cvBytes(c) });
  }
  { const c = document.createElement('canvas'); c.width = 640; c.height = 480; const x = c.getContext('2d');
    if (st.bg === 'image' && imgEl[st.bgAsset]) x.drawImage(imgEl[st.bgAsset], 0, 0, 640, 480); else { x.fillStyle = bgCol[st.bg] || '#000'; x.fillRect(0, 0, 640, 480); }
    files.push({ path: 'Sprites/bg.png', data: await cvBytes(c) }); }
  const drop = [];
  if (music.buf) {
    const ext = (music.name.match(/\.(ogg|wav)$/i) || [])[1];
    if (ext && music.blob) { files.push({ path: 'Audio/ub_music.' + ext.toLowerCase(), data: new Uint8Array(await music.blob.arrayBuffer()) }); drop.push('Audio/ub_music.' + (ext.toLowerCase() === 'ogg' ? 'wav' : 'ogg')); }
    else { files.push({ path: 'Audio/ub_music.wav', data: SBX.wav(music.buf) }); drop.push('Audio/ub_music.ogg'); }
  }
  for (const id of B.sounds) {
    const a = proj.assets.find((k) => k.id === id); if (!a) continue;
    if (a.ext === 'wav' || a.ext === 'ogg') files.push({ path: 'Sounds/' + id + '.' + a.ext, data: await dataURLBytes(a.data) });
    else if (sndBuf[id]) files.push({ path: 'Sounds/' + id + '.wav', data: SBX.wav(sndBuf[id]) });
  }
  return { folder: 'SoulBeat ' + nm, files, drop };
}
async function writeDir(root, mod) {
  const base = await root.getDirectoryHandle(mod.folder, { create: true });
  for (const f of mod.files) {
    const parts = f.path.split('/'); let d = base;
    for (let i = 0; i < parts.length - 1; i++) d = await d.getDirectoryHandle(parts[i], { create: true });
    const w = await (await d.getFileHandle(parts[parts.length - 1], { create: true })).createWritable(); await w.write(f.data); await w.close();
  }
  for (const p of mod.drop) { try { const parts = p.split('/'); const d = await base.getDirectoryHandle(parts[0]); await d.removeEntry(parts[1]); } catch (e) { } }
}
async function pickMods(forceNew) {
  let h = forceNew ? null : await idbGet('modsDir');
  if (h) { try { if ((await h.queryPermission({ mode: 'readwrite' })) !== 'granted' && (await h.requestPermission({ mode: 'readwrite' })) !== 'granted') h = null; } catch (e) { h = null; } }
  if (!h) {
    h = await window.showDirectoryPicker({ id: 'cyfmods', mode: 'readwrite' });
    if (h.name.toLowerCase() !== 'mods') { try { h = await h.getDirectoryHandle('Mods'); } catch (e) { if (!confirm(tr('There is no “Mods” folder here. Pick the Create Your Frisk folder (where the .exe is) or its Mods folder.\n\nWrite here anyway?'))) throw new Error('cancel'); } }
    idbPut('modsDir', h);
  }
  return h;
}
function exportDialog() {
  const canDir = !!window.showDirectoryPicker, nm = 'SoulBeat ' + safeName(proj.name);
  const n = B.spawns.length;
  modal(tr('<h2>SEND THE FIGHT TO THE GAME</h2><p>The editor builds a ready mod for Create Your Frisk: the fight script, pictures and music. Nothing to write by hand.</p>') +
    tr('<p class="pill" style="display:inline-block">Mod: <b style="color:#fff">') + esc(nm) + tr('</b> · objects in the fight: ') + n + (music.buf ? tr(' · track: ') + esc(music.name) : tr(' · <span style="color:#ff9f1c">no music</span>')) + '</p>' +
    '<div class="acts">' + (canDir ? tr('<button class="btn big pri" id="xDir">📂 Write straight into the game folder</button>') : '') + '<button class="btn big' + (canDir ? '' : ' pri') + tr('" id="xZip">⬇ Download ZIP</button>') + (canDir ? tr('<button class="btn big" id="xOther">Another folder…</button>') : '') + tr('<button class="btn big" id="xClose">Close</button></div>') +
    '<div id="xMsg" style="margin-top:12px"></div>' +
    tr('<ol><li><b>First time:</b> the button asks for a folder — pick the one with <b>Create Your Frisk .exe</b> (or its <b>Mods</b> folder). The browser remembers it, after that export is one click.</li><li>Start <b>Create Your Frisk</b> and choose the mod <b>') + esc(nm) + tr('</b>. If the game was already open on the mod list, restart it.</li>') + (proj.settings.waitZ ? tr('<li>The fight and music start on the <kbd>Z</kbd> key.</li>') : '') + tr('<li>ZIP way: unpack the archive into the game\'s <b>Mods</b> folder.</li></ol>'));
  const msg = (s, c) => { $('xMsg').innerHTML = '<b style="color:' + (c || '#59e391') + '">' + s + '</b>'; };
  const run = async (forceNew) => {
    try { const h = await pickMods(forceNew); msg(tr('Writing…'), '#ffe14d'); await writeDir(h, await buildMod()); msg(tr('✓ Done! The mod “') + esc(nm) + tr('” is in the game folder. Start Create Your Frisk.')); }
    catch (e) { if (e && (e.name === 'AbortError' || e.message === 'cancel')) return; msg(tr('Could not write to the folder (') + esc(e && e.message || e) + tr('). Try “Download ZIP”.'), '#ff6b6b'); }
  };
  if (canDir) { $('xDir').onclick = () => run(false); $('xOther').onclick = () => run(true); }
  $('xZip').onclick = async () => { msg(tr('Building…'), '#ffe14d'); const m = await buildMod(); download(SBX.zip(m.files.map((f) => ({ path: m.folder + '/' + f.path, data: f.data }))), m.folder + '.zip'); msg(tr('✓ ZIP downloaded. Unpack it into the game\'s Mods folder.')); };
  $('xClose').onclick = closeModal;
}
$('bExport').onclick = exportDialog;

// ---------- video recording ----------
let rec = null, recChunks = [];
function videoDialog() {
  if (!window.MediaRecorder || !cv.captureStream) return toast(tr('This browser cannot record video. Open the editor in Chrome or Edge'), 5000);
  modal(tr('<h2>RECORD VIDEO</h2><p>The fight plays from the very start and is saved as a <b>.webm</b> video file (1280×960, with sound). Drop it straight into your edit — no game needed.</p><p>The heart is controlled by: <b style="color:#fff">') + $('iCtl').selectedOptions[0].textContent + tr('</b> (change it above the battle screen). Interface and background come from “Fight settings” — e.g. a green background for chroma key.</p><p style="color:#8d8da6">The picture here is the editor preview: fonts and buttons differ slightly from the real game. Need the true in-game look? Send the fight to CYF and record the screen.</p><div class="acts"><button class="btn big pri" id="vGo">⏺ Start recording</button><button class="btn big" id="vNo">Cancel</button></div>'));
  $('vNo').onclick = closeModal;
  $('vGo').onclick = () => {
    closeModal(); pause(); ensureAudio(); recDest = actx.createMediaStreamDestination(); master.connect(recDest);
    const stream = cv.captureStream(60); recDest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
    const mime = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'].find((m) => MediaRecorder.isTypeSupported(m));
    rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 14000000 }); recChunks = [];
    rec.ondataavailable = (e) => { if (e.data.size) recChunks.push(e.data); };
    rec.onstop = () => { download(new Blob(recChunks, { type: 'video/webm' }), safeName(proj.name) + '.webm'); toast(tr('Video saved'), 3000); };
    recording = true; $('bVideo').classList.add('on'); $('bVideo').textContent = tr('■ Stop');
    seek(0); resetPlayer(); draw(); rec.start(); play();
  };
}
function stopRecording() {
  if (!recording) return; recording = false; $('bVideo').classList.remove('on'); $('bVideo').textContent = tr('⏺ Video');
  setTimeout(() => { try { rec.stop(); } catch (e) { } try { master.disconnect(recDest); } catch (e) { } }, 150);
}
$('bVideo').onclick = () => (recording ? pause() : videoDialog());

// ---------- buttons & keys ----------
$('bPlay').onclick = () => { document.activeElement && document.activeElement.blur(); toggle(); };
$('bHome').onclick = () => seek(0);
$('bDup').onclick = dupSel; $('bDel').onclick = delSel; $('bUndo').onclick = undo; $('bRedo').onclick = redo;
$('bLoop').onclick = () => { loopSel = !loopSel; syncTop(); if (loopSel && !oneSel()) toast(tr('Select one block on the timeline — it will play in a loop')); };
$('bTake').onclick = () => {
  recTake = !recTake; syncTop();
  if (recTake) { if ($('iCtl').value === 'take') $('iCtl').value = 'me'; proj.replay = null; syncTop(); toast(tr('Take recording is on. Press ▶ and play the fight — the heart\'s path is remembered'), 4500); }
  else { saveLocal(); renderInspector(); toast(proj.replay ? tr('Take recorded: ') + fmtT(proj.replay.d.length / 2 / proj.replay.hz) + tr('. Turn it on for the game in “Fight settings”') : tr('No take recorded'), 4500); }
};
$('iCtl').onchange = () => { syncTop(); $('iCtl').blur(); };
$('tabBlocks').onclick = () => { $('tabBlocks').classList.add('on'); $('tabAssets').classList.remove('on'); $('palette').style.display = ''; $('assets').style.display = 'none'; };
$('tabAssets').onclick = () => { $('tabAssets').classList.add('on'); $('tabBlocks').classList.remove('on'); $('palette').style.display = 'none'; $('assets').style.display = ''; renderAssets(); };
const HELP = {
  en: {
    h: '♥ HOW TO USE',
    li: [
      '<b>Drop a track</b> — drag an mp3 / wav / ogg into the window. The tempo is detected, the waveform and the beat grid appear below.',
      '<b>Place blocks</b> — click an attack on the left and it lands on the red line. Drag blocks with the mouse, they snap to beats; the right edge sets the length.',
      '<b>Turn the sliders</b> on the right — the result shows on the battle screen at once. Most attacks have a “Rhythm”: a volley every beat, half a beat and so on.',
      '<b>Watch</b> — <kbd>Space</kbd> plays the fight with the music. Autopilot dodges by itself, or steer with the arrow keys.',
      '<b>Enemy</b> — “👾 Enemy” puts a PNG, GIF or video above the arena. Drag it with the mouse.',
      '<b>Your assets</b> — the “Assets” tab: pictures become bullets, decorations, the enemy or the background; sounds go into the “Sound” block.',
      '<b>Done</b> — “⬇ To game (CYF)” builds a mod for Create Your Frisk, “⏺ Video” records a clip right here.',
    ],
    keys: '<kbd>Space</kbd> play / pause · <kbd>Enter</kbd> drop the chosen block by ear · <kbd>Delete</kbd> delete · <kbd>Ctrl+D</kbd> duplicate · <kbd>Ctrl+C/V</kbd> · <kbd>Ctrl+Z/Y</kbd> · <kbd>L</kbd> loop block · <kbd>M</kbd> metronome · <kbd>Alt</kbd> while dragging = no snapping · <kbd>Ctrl+wheel</kbd> = timeline zoom',
    note: 'SoulBeat is a free fan-made tool. It is not affiliated with Toby Fox, UNDERTALE or DELTARUNE.',
    ok: 'Got it, let’s go',
  },
  ru: {
    h: '♥ КАК ЭТИМ ПОЛЬЗОВАТЬСЯ',
    li: [
      '<b>Закинь трек</b> — перетащи mp3 / wav / ogg в окно. Темп определится сам, внизу появится волна и сетка битов.',
      '<b>Ставь блоки</b> — клик по атаке слева, и она встаёт на красную линию. Блоки двигаются мышкой и прилипают к битам; правый край — длина.',
      '<b>Крути ползунки</b> справа — результат сразу виден на экране боя. У большинства атак есть «Ритм»: залп каждый бит, полбита и т.д.',
      '<b>Смотри</b> — <kbd>Пробел</kbd> запускает бой с музыкой. Автопилот уворачивается сам, либо управляй стрелками.',
      '<b>Враг</b> — «👾 Враг» ставит PNG, GIF или видео над ареной. Его можно таскать мышкой.',
      '<b>Свои ассеты</b> — вкладка «Ассеты»: картинки становятся пулями, декорациями, врагом или фоном; звуки — блоком «Звук».',
      '<b>Готово</b> — «⬇ В игру (CYF)» собирает мод для Create Your Frisk, «⏺ Видео» пишет ролик прямо отсюда.',
    ],
    keys: '<kbd>Пробел</kbd> играть / пауза · <kbd>Enter</kbd> поставить выбранный блок на слух · <kbd>Delete</kbd> удалить · <kbd>Ctrl+D</kbd> дублировать · <kbd>Ctrl+C/V</kbd> · <kbd>Ctrl+Z/Y</kbd> · <kbd>L</kbd> блок по кругу · <kbd>M</kbd> метроном · <kbd>Alt</kbd> при перетаскивании — без прилипания · <kbd>Ctrl+колесо</kbd> — масштаб дорожки',
    note: 'SoulBeat — бесплатный фанатский инструмент. Он не связан с Тоби Фоксом, UNDERTALE или DELTARUNE.',
    ok: 'Понятно, поехали',
  },
};
function helpDialog() {
  const H = HELP[lang] || HELP.en, link = (id) => { const a = $(id).cloneNode(true); a.removeAttribute('id'); return a.outerHTML; };
  modal('<h2>' + H.h + ' <small style="color:#8d8da6;font-weight:400">v' + VERSION + '</small></h2><ol>' + H.li.map((x) => '<li>' + x + '</li>').join('') + '</ol><p>' + H.keys + '</p><p style="color:#8d8da6;font-size:12px">' + H.note + '</p>' +
    '<div class="acts" style="align-items:center"><button class="btn big pri" id="hOk">' + H.ok + '</button><span style="flex:1"></span>' + link('bSupport') + link('bGit') + '</div>');
  $('hOk').onclick = closeModal;
}
function setLang(l) {
  lang = l === 'ru' ? 'ru' : 'en';
  try { localStorage.setItem('sb_lang', lang); } catch (e) { }
  applyStatic(); renderPalette(); renderAssets(); renderClips(); renderInspector(); syncTop(); drawTl(); updatePlayhead(); if (!playing) draw();
}
$('langSel').onchange = (e) => { setLang(e.target.value); e.target.blur(); };
$('bMetro').onclick = () => { metro = !metro; lastBeatI = -1; syncTop(); };
$('bHelp').onclick = helpDialog;

window.addEventListener('keydown', (e) => {
  const tg = e.target, typing = (tg.tagName === 'INPUT' && (tg.type === 'text' || tg.type === 'number')) || tg.tagName === 'TEXTAREA';
  if ($('modal').classList.contains('show')) { if (e.code === 'Escape' && !recording) closeModal(); return; }
  if (typing) { if (e.code === 'Enter' || e.code === 'Escape') tg.blur(); return; }
  keys[e.code] = true;
  const ctrl = e.ctrlKey || e.metaKey;
  if (e.code === 'Space') { e.preventDefault(); if (tg.blur && tg !== document.body) tg.blur(); toggle(); }
  else if (e.code === 'Delete' || e.code === 'Backspace') { e.preventDefault(); delSel(); }
  else if (ctrl && e.code === 'KeyZ') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
  else if (ctrl && e.code === 'KeyY') { e.preventDefault(); redo(); }
  else if (ctrl && e.code === 'KeyD') { e.preventDefault(); dupSel(); }
  else if (ctrl && e.code === 'KeyC') copySel();
  else if (ctrl && e.code === 'KeyV') pasteClip();
  else if (ctrl && e.code === 'KeyS') { e.preventDefault(); saveProjectFile(); }
  else if (ctrl && e.code === 'KeyA') { e.preventDefault(); proj.clips.forEach((c) => sel.add(c.id)); renderClips(); renderInspector(); }
  else if (e.code === 'Enter') { e.preventDefault(); if (armed) addClip(armed, curT); }
  else if (e.code === 'KeyL' && !ctrl) $('bLoop').click();
  else if (e.code === 'KeyM' && !ctrl) $('bMetro').click();
  else if (e.code === 'Home') seek(0);
  else if (e.code === 'Escape') { sel.clear(); renderClips(); renderInspector(); if (!playing) draw(); }
  else if (e.code.startsWith('Arrow')) { if (ctlMode() === 'me' && playing) e.preventDefault(); else if (!playing && (e.code === 'ArrowLeft' || e.code === 'ArrowRight') && tg.type !== 'range') { e.preventDefault(); const u = beatLen() * (snapDiv() || 0.25); seek(snapT(curT + (e.code === 'ArrowLeft' ? -u : u))); } }
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });
window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; });
window.addEventListener('resize', () => { fitStage(); drawTl(); });
{ // timeline height splitter
  let sp = null; const s = $('split');
  s.addEventListener('pointerdown', (e) => { sp = 1; s.setPointerCapture(e.pointerId); });
  s.addEventListener('pointermove', (e) => { if (!sp) return; document.documentElement.style.setProperty('--tlh', clampN(window.innerHeight - e.clientY, 140, window.innerHeight - 260) + 'px'); fitStage(); drawTl(); });
  s.addEventListener('pointerup', () => { sp = null; });
}

// ---------- init ----------
(async function init() {
  buildSprites(); applyStatic();
  rebake(); resetPlayer(); renderPalette(); renderClips(); renderInspector(); syncTop(); fitStage(); drawTl(); updatePlayhead(); draw();
  requestAnimationFrame(frame);
  const saved = await idbGet('proj');
  if (saved && saved.app === 'soulbeat') {
    const mus = await idbGet('music');
    try { await loadProject(saved, mus && mus.blob ? mus : null); } catch (e) { }
  }
  if (!localStorage.getItem('sb_seen')) { try { localStorage.setItem('sb_seen', '1'); } catch (e) { } helpDialog(); }
  window.__sb = { buildMod, setLang, animFr, sprCv, get proj() { return proj; }, get B() { return B; }, addClip, seek, play, pause, loadProject, demoProject };
})();
