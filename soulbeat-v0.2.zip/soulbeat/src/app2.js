// ===== SoulBeat app, part 2: timeline, palette, inspector, assets =====
const RUL = 20, WAVH = 44, LT = RUL + WAVH, LH = 28;
const tlS = $('tlscroll'), tlI = $('tlinner'), tlC = $('tlbg'), tlx = tlC.getContext('2d'), clipsEl = $('clips'), phEl = $('ph');
let pps = 90;
const snapDiv = () => +$('iSnap').value;
function snapT(t, e) {
  const d = snapDiv(); if (!d || (e && e.altKey)) return Math.max(0, t);
  const u = beatLen() * d; return Math.max(0, proj.offset + Math.round((t - proj.offset) / u) * u);
}
function laneCount() { let m = 0; for (const c of proj.clips) if (c.lane > m) m = c.lane; return Math.max(6, m + 2); }
function layoutTl() {
  const w = Math.max(tlS.clientWidth, proj.duration * pps + 240), h = Math.max(tlS.clientHeight - 2, LT + laneCount() * LH);
  tlI.style.width = w + 'px'; tlI.style.height = h + 'px';
  const dpr = window.devicePixelRatio || 1, vw = tlS.clientWidth;
  if (tlC.width !== Math.round(vw * dpr) || tlC.height !== Math.round(h * dpr)) { tlC.width = Math.round(vw * dpr); tlC.height = Math.round(h * dpr); tlC.style.width = vw + 'px'; tlC.style.height = h + 'px'; }
  clipsEl.style.width = w + 'px'; clipsEl.style.height = h + 'px'; phEl.style.height = h + 'px';
}
function fmtT(t) { const m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s.toFixed(2); }
function drawTl() {
  layoutTl();
  const dpr = window.devicePixelRatio || 1, W = tlS.clientWidth, H = tlC.height / dpr, sx = tlS.scrollLeft;
  tlx.setTransform(dpr, 0, 0, dpr, 0, 0);
  tlx.fillStyle = '#0d0d13'; tlx.fillRect(0, 0, W, H);
  tlx.fillStyle = '#16161f'; tlx.fillRect(0, 0, W, RUL);
  tlx.fillStyle = '#101018'; tlx.fillRect(0, RUL, W, WAVH);
  const n = laneCount();
  for (let i = 0; i < n; i++) { tlx.fillStyle = i % 2 ? '#12121a' : '#15151e'; tlx.fillRect(0, LT + i * LH, W, LH); }
  const endX = proj.duration * pps - sx;
  if (endX < W) { tlx.fillStyle = '#00000088'; tlx.fillRect(Math.max(0, endX), 0, W, H); }
  // waveform
  if (music.peaks) {
    tlx.fillStyle = '#4b6cff';
    const pk = music.peaks, mid = RUL + WAVH / 2;
    for (let x = 0; x < W; x++) {
      const a = Math.floor(((x + sx) / pps) * 100), b = Math.max(a + 1, Math.floor(((x + 1 + sx) / pps) * 100));
      let m = 0; for (let i = a; i < b && i < pk.length; i++) if (pk[i] > m) m = pk[i];
      if (m > 0) tlx.fillRect(x, mid - m * WAVH / 2, 1, Math.max(1, m * WAVH));
    }
  } else { tlx.fillStyle = '#55556e'; tlx.font = '12px Segoe UI, sans-serif'; tlx.fillText(tr('Drop a track here or press “🎵 Music” — the waveform will appear here'), 12 , RUL + WAVH / 2 + 4); }
  // beat grid
  const bl = beatLen(), pxBeat = bl * pps;
  let stepB = 1; while (pxBeat * stepB < 7) stepB *= 2;
  const i0 = Math.floor((sx / pps - proj.offset) / bl), i1 = Math.ceil(((sx + W) / pps - proj.offset) / bl);
  tlx.font = '10px Consolas, monospace';
  for (let i = Math.max(0, i0); i <= i1; i++) {
    if (i % stepB) continue;
    const x = Math.round((proj.offset + i * bl) * pps - sx) + 0.5, bar = i % 4 === 0;
    tlx.strokeStyle = bar ? '#3d3d58' : '#23232f'; tlx.beginPath(); tlx.moveTo(x, bar ? 0 : RUL); tlx.lineTo(x, H); tlx.stroke();
    if (bar && (pxBeat * 4 > 34 || i % 16 === 0)) { tlx.fillStyle = '#9a9ab5'; tlx.fillText(String(i / 4 + 1), x + 3, 13); }
  }
  const sub = snapDiv();
  if (sub && sub < 1 && pxBeat * sub > 9) {
    tlx.strokeStyle = '#1b1b25';
    for (let q = Math.max(0, Math.floor(i0 / sub)); q <= i1 / sub; q++) { if (Math.abs(q * sub - Math.round(q * sub)) < 0.001) continue; const x = Math.round((proj.offset + q * sub * bl) * pps - sx) + 0.5; tlx.beginPath(); tlx.moveTo(x, LT); tlx.lineTo(x, H); tlx.stroke(); }
  }
}
function updatePlayhead(follow) {
  phEl.style.left = curT * pps - 1 + 'px';
  const bl = beatLen(), bt = Math.max(0, (curT - proj.offset) / bl);
  $('time').innerHTML = fmtT(curT) + tr('<small>bar ') + (Math.floor(bt / 4) + 1) + '.' + (Math.floor(bt % 4) + 1) + '</small>';
  if (follow) { const x = curT * pps - tlS.scrollLeft; if (x > tlS.clientWidth - 80 || x < 0) tlS.scrollLeft = curT * pps - 120; }
}
function renderClips() {
  layoutTl(); clipsEl.innerHTML = '';
  for (const c of proj.clips) {
    const d = PAT[c.type]; if (!d) continue;
    const e = el('div', 'clip' + (sel.has(c.id) ? ' sel' : '') + (c.off ? ' off' : ''), '<span>' + d.icon + ' ' + esc(tr(d.name)) + '</span><div class="rz"></div>');
    e.dataset.id = c.id; e.style.setProperty('--c', d.color); placeClip(e, c); clipsEl.appendChild(e);
  }
}
function placeClip(e, c) { e.style.left = c.t * pps + 'px'; e.style.width = Math.max(8, c.d * pps - 1) + 'px'; e.style.top = LT + c.lane * LH + 2 + 'px'; }
function freeLane(t, d, skip) {
  for (let l = 0; l < 40; l++) { if (!proj.clips.some((c) => c !== skip && c.lane === l && c.t < t + d - 0.001 && t < c.t + c.d - 0.001)) return l; }
  return 0;
}
function addClip(type, t, lane, over) {
  pushUndo();
  const d = PAT[type], dur = Math.max(0.05, d.dur * beatLen());
  t = clampN(snapT(t), 0, Math.max(0, proj.duration - 0.05));
  const c = { id: proj.nextId++, type, lane: 0, t, d: dur, p: Object.assign(SB.defaults(type), over || {}) };
  if (c.p.seed !== undefined) c.p.seed = 1 + Math.floor(Math.random() * 9999);
  if (type === 'arena') { const A = sim.arena(t); if (!over) Object.assign(c.p, { w: Math.round(A.w), h: Math.round(A.h), ax: Math.round(A.x), ay: Math.round(A.y) }); }
  c.lane = lane != null && !proj.clips.some((o) => o.lane === lane && o.t < t + dur - 0.001 && t < o.t + o.d - 0.001) ? lane : freeLane(t, dur);
  proj.clips.push(c); sel.clear(); sel.add(c.id); changed(true);
  return c;
}
function delSel() { if (!sel.size) return; pushUndo(); proj.clips = proj.clips.filter((c) => !sel.has(c.id)); sel.clear(); changed(true); }
function dupSel() {
  if (!sel.size) return; pushUndo();
  const src = proj.clips.filter((c) => sel.has(c.id)); const t0 = Math.min(...src.map((c) => c.t)), t1 = Math.max(...src.map((c) => c.t + c.d));
  sel.clear();
  for (const s of src) { const c = JSON.parse(JSON.stringify(s)); c.id = proj.nextId++; c.t = s.t + (t1 - t0); c.lane = freeLane(c.t, c.d) <= s.lane ? s.lane : s.lane; if (proj.clips.some((o) => o.lane === c.lane && o.t < c.t + c.d - 0.001 && c.t < o.t + o.d - 0.001)) c.lane = freeLane(c.t, c.d); proj.clips.push(c); sel.add(c.id); }
  changed(true);
}
let clipboard = [];
function copySel() { clipboard = proj.clips.filter((c) => sel.has(c.id)).map((c) => JSON.parse(JSON.stringify(c))); if (clipboard.length) toast(tr('Copied: ') + clipboard.length); }
function pasteClip() {
  if (!clipboard.length) return; pushUndo(); const t0 = Math.min(...clipboard.map((c) => c.t)); sel.clear();
  for (const s of clipboard) { const c = JSON.parse(JSON.stringify(s)); c.id = proj.nextId++; c.t = snapT(curT) + (s.t - t0); c.lane = freeLane(c.t, c.d); proj.clips.push(c); sel.add(c.id); }
  changed(true);
}

// timeline pointer interaction
let drag = null;
tlI.addEventListener('pointerdown', (e) => {
  if (e.button !== 0) return;
  const r = tlI.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
  const ce = e.target.closest('.clip');
  tlI.setPointerCapture(e.pointerId);
  if (ce) {
    const c = clipById(+ce.dataset.id);
    if (e.shiftKey || e.ctrlKey) { sel.has(c.id) ? sel.delete(c.id) : sel.add(c.id); }
    else if (!sel.has(c.id)) { sel.clear(); sel.add(c.id); }
    const items = proj.clips.filter((k) => sel.has(k.id)).map((k) => ({ c: k, t: k.t, d: k.d, lane: k.lane }));
    drag = { kind: e.target.classList.contains('rz') ? 'rz' : 'mv', x, y, c, items, moved: false, snap: snap0() };
    renderClips(); renderInspector(); if (!playing) draw();
  } else {
    drag = { kind: 'seek' }; if (y >= LT && !e.shiftKey) { sel.clear(); renderClips(); renderInspector(); }
    seek(x / pps);
  }
});
tlI.addEventListener('pointermove', (e) => {
  if (!drag) return;
  const r = tlI.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
  if (drag.kind === 'seek') { seek(x / pps); return; }
  const dx = x - drag.x, dy = y - drag.y;
  if (!drag.moved && Math.abs(dx) < 3 && Math.abs(dy) < 5) return;
  drag.moved = true;
  const me = drag.items.find((i) => i.c === drag.c);
  if (drag.kind === 'mv') {
    const nt = snapT(me.t + dx / pps, e), dt = nt - me.t, dl = Math.round(dy / LH);
    for (const i of drag.items) { i.c.t = Math.max(0, i.t + dt); i.c.lane = clampN(i.lane + dl, 0, 30); }
  } else {
    const ne = snapT(me.t + me.d + dx / pps, e), minD = snapDiv() ? beatLen() * snapDiv() : 0.05;
    for (const i of drag.items) i.c.d = Math.max(Math.min(minD, 0.25), i.d + (ne - (me.t + me.d)));
  }
  for (const n of clipsEl.children) { const c = clipById(+n.dataset.id); if (c && sel.has(c.id)) placeClip(n, c); }
  clearTimeout(bakeTimer); bakeTimer = setTimeout(() => { rebake(); if (!playing) draw(); }, 40);
});
tlI.addEventListener('pointerup', () => {
  if (drag && drag.moved) { undoSt.push(drag.snap); redoSt.length = 0; changed(true); }
  drag = null;
});
tlS.addEventListener('scroll', drawTl);
tlS.addEventListener('wheel', (e) => {
  if (e.ctrlKey || e.altKey) { e.preventDefault(); const r = tlI.getBoundingClientRect(), tAt = (e.clientX - r.left) / pps; setZoom(pps * (e.deltaY < 0 ? 1.2 : 1 / 1.2)); tlS.scrollLeft = tAt * pps - (e.clientX - tlS.getBoundingClientRect().left); }
  else if (!e.shiftKey && Math.abs(e.deltaY) > Math.abs(e.deltaX) && tlI.offsetHeight <= tlS.clientHeight + 4) { e.preventDefault(); tlS.scrollLeft += e.deltaY; }
}, { passive: false });
function setZoom(v) { pps = clampN(v, 12, 400); $('iZoom').value = pps; renderClips(); drawTl(); updatePlayhead(); }
$('iZoom').addEventListener('input', (e) => setZoom(+e.target.value));

// drag blocks from the palette onto the timeline
tlS.addEventListener('dragover', (e) => { if (e.dataTransfer.types.includes('text/sb')) e.preventDefault(); });
tlS.addEventListener('drop', (e) => {
  const type = e.dataTransfer.getData('text/sb'); if (!type) return; e.preventDefault(); e.stopPropagation();
  const r = tlI.getBoundingClientRect();
  addClip(type, (e.clientX - r.left) / pps, clampN(Math.floor((e.clientY - r.top - LT) / LH), 0, 30));
});

// ---------- palette ----------
function renderPalette() {
  const root = $('palette'); root.innerHTML = '';
  for (const [cid, cname] of CATS) {
    root.appendChild(el('div', 'cat', tr(cname)));
    const grid = el('div', 'cards');
    for (const type in PAT) {
      const d = PAT[type]; if (d.cat !== cid) continue;
      const c = el('div', 'card' + (armed === type ? ' armed' : ''), '<b>' + d.icon + '</b><span>' + tr(d.name) + '</span>');
      c.style.setProperty('--c', d.color); c.title = tr(d.hint); c.draggable = true;
      c.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/sb', type); });
      c.addEventListener('click', () => { armed = type; addClip(type, curT); renderPalette(); });
      grid.appendChild(c);
    }
    root.appendChild(grid);
  }
  root.appendChild(el('div', 'tip', tr('Click — the block lands on the red line.<br>Or drag it onto a lane.<br><br>Every block is a ready-made attack or effect. Everything is tuned with the sliders on the right, and you see the result at once.')));
}

// ---------- assets ----------
function setEnemy(id) {
  pushUndo(); proj.settings.monsterAsset = id; sel.clear(); changed(true);
  if (id) toast(tr('Enemy placed. Drag it with the mouse; size and position are in “Fight settings”'), 4500);
}
function renderAssets() {
  const root = $('assets'); root.innerHTML = '';
  const dz = el('div', 'drop', tr('＋ Add your own files<br><small>PNG, GIF, video, WAV / OGG / MP3</small>')); dz.onclick = () => $('fAssets').click(); root.appendChild(dz);
  if (!proj.assets.length) root.appendChild(el('div', 'tip', tr('Pictures can be bullets, decorations, the enemy or the background. Sounds go into the “Sound” block.<br><br>You can simply drop files into the window.')));
  for (const a of proj.assets) {
    const r = el('div', 'asset'), vis = a.kind !== 'sound';
    r.innerHTML = '<div class="th">' + (vis ? '<img src="' + (a.kind === 'anim' ? a.thumb || '' : a.data) + '">' : '🔊') + '</div><div class="nm" title="' + esc(a.name) + '">' + esc(a.name) + (vis ? '<br><small style="color:#8d8da6">' + a.w + '×' + a.h + (a.kind === 'anim' ? ' · ' + a.n + tr(' frames') : '') + '</small>' : '') + '</div>';
    const btn = (txt, title, fn) => { const b = el('button', 'btn', txt); b.title = title; b.onclick = fn; r.appendChild(b); };
    if (a.kind === 'sound') { btn('▶', tr('Listen'), () => { ensureAudio().resume(); playSnd(a.id); }); btn('＋', tr('Put the sound on a lane'), () => addClip('sound', curT, null, { snd: a.id })); }
    if (a.kind === 'image') btn('＋', tr('Put on stage'), () => addClip('object', curT, null, { spr: a.id }));
    if (vis) btn('👾', tr('Make it the enemy above the arena'), () => setEnemy(a.id));
    const x = el('div', 'x', '✕'); x.title = tr('Delete');
    x.onclick = () => { proj.assets = proj.assets.filter((k) => k !== a); delete imgEl[a.id]; delete sndBuf[a.id]; delete animFr[a.id]; if (proj.settings.monsterAsset === a.id) proj.settings.monsterAsset = ''; renderAssets(); changed(true); };
    r.appendChild(x); root.appendChild(r);
  }
}
async function addAssetFile(f) {
  const isVid = f.type.startsWith('video'), isImg = f.type.startsWith('image');
  if (isVid && f.size > 80 * 1024 * 1024) throw new Error('too big');
  const data = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(f); });
  const a = { id: 'u' + proj.nextAsset++, name: f.name.replace(/\.[^.]+$/, ''), kind: isVid ? 'anim' : isImg ? 'image' : 'sound', data };
  if (isImg && (await isAnimatedImage(f, f.type))) a.kind = 'anim';
  if (a.kind === 'anim') {
    a.mime = f.type; a.key = '';
    await decodeAnim(a, (k) => toast(tr('Preparing the animation… ') + Math.round(k * 100) + '%', 20000));
    toast(tr('Animation ready: ') + a.n + tr(' frames'), 1500);
  } else if (a.kind === 'image') {
    const im = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = data; });
    let w = im.width, h = im.height; const k = Math.min(1, 640 / Math.max(w, h)); w = Math.max(1, Math.round(w * k)); h = Math.max(1, Math.round(h * k));
    const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(im, 0, 0, w, h);
    a.data = c.toDataURL('image/png'); a.w = w; a.h = h; imgEl[a.id] = c;
  } else { a.ext = (f.name.match(/\.([^.]+)$/) || [0, 'wav'])[1].toLowerCase(); }
  proj.assets.push(a);
  if (a.kind === 'sound') await loadAssetMedia(a);
  return a;
}

// ---------- inspector ----------
function numCtl(v, d, on) {
  const w = el('div', 'ctl'), r = el('input'), n = el('input', 'in');
  r.type = 'range'; n.type = 'number';
  for (const i of [r, n]) { i.min = d.min; i.max = d.max; i.step = d.step; i.value = v; }
  r.oninput = () => { n.value = r.value; on(+r.value); };
  n.oninput = () => { if (n.value === '' || isNaN(+n.value)) return; r.value = n.value; on(+n.value); };
  w.appendChild(r); w.appendChild(n); return w;
}
function selCtl(v, opts, on) { const s = el('select', 'in'); for (const [val, lab] of opts) { const o = el('option', '', esc(tr(lab))); o.value = val; s.appendChild(o); } s.value = v; s.onchange = () => on(s.value); return s; }
function row(label, ctl, title) { const r = el('div', 'row'); const l = el('label', '', esc(tr(label))); if (title) r.title = title; r.appendChild(l); if (ctl.classList && ctl.classList.contains('ctl')) r.appendChild(ctl); else { const w = el('div', 'ctl'); w.appendChild(ctl); r.appendChild(w); } return r; }
function colorCtl(v, req, on) {
  const w = el('div', 'ctl'), c = el('input'); c.type = 'color'; c.value = v || '#ffffff';
  c.oninput = () => { if (cb) cb.checked = false; on(c.value); };
  let cb = null;
  if (!req) { cb = el('input'); cb.type = 'checkbox'; cb.checked = !v; cb.onchange = () => on(cb.checked ? '' : c.value); const l = el('label', '', ''); l.style.cssText = 'display:flex;align-items:center;gap:4px;color:#8d8da6'; l.appendChild(cb); l.appendChild(document.createTextNode(tr('same as type'))); w.appendChild(c); w.appendChild(l); }
  else w.appendChild(c);
  return w;
}
function spriteGrid(v, on) {
  const gEl = el('div', 'sprgrid');
  const cell = (nme, title) => {
    const d = el('div', v === nme ? 'on' : ''); const sp = getSprite(nme); const c = document.createElement('canvas'); c.width = sp.width; c.height = sp.height; c.getContext('2d').drawImage(sp, 0, 0);
    const k = Math.max(1, Math.floor(28 / Math.max(sp.width, sp.height))); c.style.width = sp.width * k + 'px';
    d.title = title; d.appendChild(c); d.onclick = () => on(nme); gEl.appendChild(d);
  };
  for (const [gid, gname] of SB.SPRG) {
    gEl.appendChild(el('div', 'grp', esc(tr(gname))));
    for (const k in SPR) if (!SPR[k].hidden && (SPR[k].g || 'basic') === gid) cell(k, tr(SPR[k].name));
  }
  gEl.appendChild(el('div', 'grp', esc(tr('Your pictures'))));
  for (const a of proj.assets) if (a.kind === 'image') cell(a.id, a.name);
  const plus = el('div', '', '＋'); plus.title = tr('Add your own picture'); plus.style.color = '#8d8da6'; plus.onclick = () => $('fAssets').click(); gEl.appendChild(plus);
  return gEl;
}
function renderInspector() {
  const root = $('right'); const keepScroll = root.scrollTop; root.innerHTML = '';
  const c = oneSel();
  if (sel.size > 1) { root.appendChild(el('h3', '', tr('Blocks selected: ') + sel.size)); root.appendChild(el('div', 'hint', tr('You can move, duplicate (Ctrl+D) and delete (Delete) them together.'))); return; }
  if (!c) { renderSettings(root); root.scrollTop = keepScroll; return; }
  const d = PAT[c.type], bl = beatLen();
  root.appendChild(el('h3', '', '<span style="color:' + d.color + '">' + d.icon + '</span> ' + tr(d.name)));
  root.appendChild(el('div', 'hint', tr(d.hint)));
  const set = (k, v, rerender) => { pushUndo('p' + c.id + k); c.p[k] = v; changed(false); if (rerender) renderInspector(); };
  root.appendChild(row(tr('Start, beat'), numCtl(+((c.t - proj.offset) / bl).toFixed(3), { min: 0, max: Math.ceil(proj.duration / bl), step: 0.25 }, (v) => { pushUndo('t' + c.id); c.t = Math.max(0, proj.offset + v * bl); changed(false); renderClips(); }), tr('When the block starts (in beats from the first beat)')));
  root.appendChild(row(tr('Length, beats'), numCtl(+(c.d / bl).toFixed(3), { min: 0.25, max: 128, step: 0.25 }, (v) => { pushUndo('d' + c.id); c.d = Math.max(0.05, v * bl); changed(false); renderClips(); }), tr('How long the block lasts')));
  for (const pd of d.params) {
    if (pd.show && !pd.show(c.p)) continue;
    if (pd.type === 'num') root.appendChild(row(pd.label, numCtl(c.p[pd.k], pd, (v) => set(pd.k, v))));
    else if (pd.type === 'sel') root.appendChild(row(pd.label, selCtl(c.p[pd.k], pd.opts, (v) => set(pd.k, v, true))));
    else if (pd.type === 'bool') { const i = el('input'); i.type = 'checkbox'; i.checked = !!c.p[pd.k]; i.onchange = () => set(pd.k, i.checked); root.appendChild(row(pd.label, i)); }
    else if (pd.type === 'color') root.appendChild(row(pd.label, colorCtl(c.p[pd.k], pd.req, (v) => set(pd.k, v))));
    else if (pd.type === 'seed') { const b = el('button', 'btn', tr('🎲 Shuffle')); b.onclick = () => set('seed', 1 + Math.floor(Math.random() * 9999)); root.appendChild(row(pd.label, b)); }
    else if (pd.type === 'sound') { const snds = proj.assets.filter((a) => a.kind === 'sound'); root.appendChild(row(pd.label, snds.length ? selCtl(c.p.snd, [['', tr('— choose —')]].concat(snds.map((a) => [a.id, a.name])), (v) => set('snd', v)) : el('span', '', tr('<span style="color:#8d8da6">add a sound in the “Assets” tab first</span>')))); }
    else if (pd.type === 'sprite') { root.appendChild(el('div', 'row', '<label>' + tr(pd.label) + '</label>')); root.appendChild(spriteGrid(c.p[pd.k], (v) => set(pd.k, v, true))); }
    else if (pd.type === 'pos') {
      const w = el('div', 'ctl');
      for (const ax of ['x', 'y']) { const i = el('input', 'in'); i.type = 'number'; i.step = 5; i.value = Math.round(c.p[ax]); i.oninput = () => { if (i.value !== '' && !isNaN(+i.value)) set(ax, +i.value); }; w.appendChild(document.createTextNode(ax.toUpperCase())); w.appendChild(i); }
      root.appendChild(row(pd.label, w, tr('Easiest: drag the yellow crosshair right on the battle screen')));
      root.appendChild(el('div', 'tip', tr('✛ drag it with the mouse right on the battle screen')));
    }
  }
  const acts = el('div', 'acts');
  const b1 = el('button', 'btn', tr('▶ Play block')); b1.onclick = () => { seek(Math.max(0, c.t - 0.5)); play(); };
  const b2 = el('button', 'btn', c.off ? tr('👁 Enable') : tr('🚫 Disable')); b2.onclick = () => { pushUndo(); c.off = !c.off; changed(true); };
  const b3 = el('button', 'btn', tr('Duplicate')); b3.onclick = dupSel;
  const b4 = el('button', 'btn', tr('Delete')); b4.onclick = delSel;
  acts.append(b1, b2, b3, b4); root.appendChild(acts);
  root.scrollTop = keepScroll;
}
function renderSettings(root) {
  const st = proj.settings;
  root.appendChild(el('h3', '', tr('⚙ Fight settings')));
  root.appendChild(el('div', 'hint', tr('Select a block on the timeline to tune it. General settings live here.')));
  const S2 = (o, k, rer) => (v) => { pushUndo('s' + k); o[k] = v; changed(false); if (rer) renderInspector(); syncTop(); drawTl(); };
  const txt = (o, k, ph) => { const i = el('input', 'in'); i.type = 'text'; i.value = o[k] || ''; i.placeholder = ph || ''; i.oninput = () => S2(o, k)(i.value); return i; };
  const chk = (o, k, rer) => { const i = el('input'); i.type = 'checkbox'; i.checked = !!o[k]; i.onchange = () => S2(o, k, rer)(i.checked); return i; };
  const imgs = [['', tr('— none —')]].concat(proj.assets.filter((a) => a.kind === 'image').map((a) => [a.id, a.name]));
  root.appendChild(row(tr('Title'), txt(proj, 'name')));
  root.appendChild(row(tr('Fight length, s'), numCtl(+proj.duration.toFixed(2), { min: 2, max: music.buf ? Math.ceil(music.buf.duration) : 900, step: 0.5 }, S2(proj, 'duration')), music.buf ? tr('Equals the track length by default. You can shorten it') : tr('How long the fight lasts')));
  root.appendChild(el('div', 'sec', tr('Picture')));
  root.appendChild(row(tr('Background'), selCtl(st.bg, [['black', tr('Black')], ['green', tr('Green (chroma key)')], ['blue', tr('Blue (chroma key)')], ['magenta', tr('Magenta (chroma key)')], ['image', tr('Custom picture')]], S2(st, 'bg', true)), tr('A chroma key is easy to cut out in a video editor to overlay the fight on your own video')));
  if (st.bg === 'image') root.appendChild(row(tr('Background picture'), selCtl(st.bgAsset, imgs, S2(st, 'bgAsset'))));
  root.appendChild(row(tr('Hide interface'), chk(st, 'hideUI'), tr('Removes the name, HP and FIGHT/ACT buttons — only the arena stays')));
  root.appendChild(el('div', 'sec', tr('Enemy')));
  const ens = [['', tr('— none —')]].concat(proj.assets.filter((a) => a.kind === 'image' || a.kind === 'anim').map((a) => [a.id, a.name]));
  root.appendChild(row(tr('Enemy'), selCtl(st.monsterAsset, ens, S2(st, 'monsterAsset', true)), tr('A picture, GIF or video above the arena. “None” = empty (for example if the character comes from your own video)')));
  { const a = el('div', 'acts'); const b = el('button', 'btn', tr('＋ Add enemy file (PNG, GIF, video)')); b.onclick = () => $('fEnemy').click(); a.appendChild(b); root.appendChild(a); }
  if (st.monsterAsset) {
    const ea = proj.assets.find((a) => a.id === st.monsterAsset);
    root.appendChild(row(tr('Enemy size'), numCtl(st.monsterScale || 1, { min: 0.1, max: 6, step: 0.05 }, S2(st, 'monsterScale'))));
    root.appendChild(row(tr('Enemy: shift X'), numCtl(st.monsterX, { min: -320, max: 320, step: 1 }, S2(st, 'monsterX')), tr('You can also drag the enemy with the mouse on the battle screen')));
    root.appendChild(row(tr('Enemy: shift Y'), numCtl(st.monsterY, { min: -300, max: 300, step: 1 }, S2(st, 'monsterY'))));
    if (ea && ea.kind === 'anim') {
      root.appendChild(row(tr('Cut out background'), selCtl(ea.key || '', [['', 'No'], ['green', 'Green'], ['blue', 'Blue'], ['magenta', 'Magenta'], ['black', 'Black'], ['white', 'White']], async (v) => {
        ea.key = v; toast(tr('Preparing the animation… '), 20000);
        try { await decodeAnim(ea); } catch (e) { }
        toast(tr('Done'), 800); changed(false); renderAssets(); if (!playing) draw();
      }), tr('Removes a plain background colour from the GIF or video, for example a green screen')));
      root.appendChild(el('div', 'tip', tr('Frames: ') + ea.n + ' · ' + (animFr[ea.id] ? animFr[ea.id].fps : '?') + tr(' fps. A long video is cut to its first 20 seconds, and its sound is not used.')));
    }
  }
  root.appendChild(el('div', 'sec', tr('Starting arena')));
  root.appendChild(row(tr('Width'), numCtl(st.arena.w, { min: 20, max: 600, step: 5 }, S2(st.arena, 'w'))));
  root.appendChild(row(tr('Height'), numCtl(st.arena.h, { min: 20, max: 400, step: 5 }, S2(st.arena, 'h'))));
  root.appendChild(row(tr('Centre X'), numCtl(st.arena.x, { min: 20, max: 620, step: 5 }, S2(st.arena, 'x'))));
  root.appendChild(row(tr('Bottom Y'), numCtl(st.arena.y, { min: 0, max: 440, step: 5 }, S2(st.arena, 'y'))));
  root.appendChild(el('div', 'sec', tr('Player')));
  root.appendChild(row(tr('Name'), txt(st, 'playerName')));
  root.appendChild(row(tr('Level (LV)'), numCtl(st.lv, { min: 1, max: 20, step: 1 }, (v) => { S2(st, 'lv')(v); hp = maxHp(); }), tr('The level sets the HP pool')));
  root.appendChild(row(tr('Bullet damage'), numCtl(st.damage, { min: 0, max: 99, step: 1 }, S2(st, 'damage'))));
  root.appendChild(row(tr('Invincibility, s'), numCtl(st.inv, { min: 0.1, max: 5, step: 0.1 }, S2(st, 'inv')), tr('How long the heart blinks after a hit')));
  root.appendChild(row(tr('Immortal'), chk(st, 'god'), tr('HP goes down but the fight never ends in GAME OVER — handy for video')));
  root.appendChild(el('div', 'sec', tr('In the game (CYF)')));
  root.appendChild(row(tr('Start on Z key'), chk(st, 'waitZ'), tr('The fight and music start when you press Z — time to start your screen recorder')));
  root.appendChild(row(tr('When the track ends'), selCtl(st.endAction, [['stay', tr('Stay on screen')], ['loop', tr('Start over')], ['done', tr('Leave the fight')]], S2(st, 'endAction'))));
  root.appendChild(row(tr('Sync nudge, ms'), numCtl(st.sync, { min: -300, max: 300, step: 5 }, S2(st, 'sync')), tr('If bullets run a bit late or early against the music in the game — shift this')));
  const hasTake = proj.replay && proj.replay.d.length > 60;
  root.appendChild(row(tr('Play the take'), hasTake ? chk(st, 'cyfReplay') : el('span', '', tr('<span style="color:#8d8da6">no take recorded yet</span>')), tr('In the game the heart will walk through the fight by itself along your recorded take')));
  if (hasTake) { const a = el('div', 'acts'); a.appendChild(el('span', 'pill', tr('Take: ') + fmtT(proj.replay.d.length / 2 / proj.replay.hz))); const b = el('button', 'btn', tr('Erase take')); b.onclick = () => { proj.replay = null; st.cyfReplay = false; changed(true); }; a.appendChild(b); root.appendChild(a); }
}

// ---------- drag the position handle / soul on the preview ----------
function cvPos(e) { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * 640, 480 - (e.clientY - r.top) / r.height * 480]; }
cv.addEventListener('pointerdown', (e) => {
  const c = oneSel(), [x, y] = cvPos(e), A = sim.arena(curT), cx = A.x, cy = A.y + 5 + A.h / 2;
  cv.setPointerCapture(e.pointerId);
  if (c && !playing && PAT[c.type].params.some((d) => d.type === 'pos' && (!d.show || d.show(c.p)))) { pushUndo(); dragPos = { c, cx, cy }; c.p.x = Math.round(x - cx); c.p.y = Math.round(y - cy); changed(false); }
  else if (!playing && enemyHit(x, y, A)) { pushUndo(); const st = proj.settings; dragPos = { enemy: 1, x, y, mx: st.monsterX || 0, my: st.monsterY || 0 }; }
  else { dragPos = { soul: 1 }; P.x = x; P.y = y; clampSoul(A); if (!playing) draw(); }
});
function enemyHit(x, y, A) {
  const E = enemyGfx(); if (!E) return false;
  const st = proj.settings, sc = st.monsterScale || 1, w = E.frames[0].width * sc, h = E.frames[0].height * sc, cx = 320 + (st.monsterX || 0), by = A.y + A.h + 11 + (st.monsterY || 0);
  return x >= cx - w / 2 && x <= cx + w / 2 && y >= by && y <= by + h;
}
cv.addEventListener('pointermove', (e) => {
  if (!dragPos) return; const [x, y] = cvPos(e);
  if (dragPos.enemy) { const st = proj.settings; st.monsterX = Math.round(dragPos.mx + x - dragPos.x); st.monsterY = Math.round(dragPos.my + y - dragPos.y); draw(); return; }
  if (dragPos.c) { let nx = Math.round(x - dragPos.cx), ny = Math.round(y - dragPos.cy); if (!e.altKey) { nx = Math.round(nx / 5) * 5; ny = Math.round(ny / 5) * 5; } dragPos.c.p.x = nx; dragPos.c.p.y = ny; changed(false); }
  else { P.x = x; P.y = y; clampSoul(sim.arena(curT)); if (!playing) draw(); }
});
cv.addEventListener('pointerup', () => { if (dragPos && dragPos.c) renderInspector(); if (dragPos && dragPos.enemy) changed(true); dragPos = null; });

function fitStage() {
  const s = $('stage'), k = Math.min((s.clientWidth - 24) / 640, (s.clientHeight - 24) / 480);
  cv.style.width = Math.floor(640 * k) + 'px'; cv.style.height = Math.floor(480 * k) + 'px';
}
function syncTop() {
  $('iBpm').value = +(+proj.bpm).toFixed(2); $('iOff').value = +(+proj.offset).toFixed(3);
  $('song').textContent = music.name || tr('no track chosen'); document.title = proj.name + ' — SoulBeat';
  $('bTake').classList.toggle('on', recTake); $('bLoop').classList.toggle('on', loopSel); $('bMetro').classList.toggle('on', metro); $('langSel').value = lang;
  $('stagehint').textContent = ctlMode() === 'me' ? tr('Arrows or WASD move the heart, X / Shift = slower') : ctlMode() === 'take' ? (proj.replay ? tr('The heart follows the recorded take') : tr('No take yet — turn on “● Record take” and play the fight')) : tr('Autopilot dodges by itself. You can move the heart with the mouse');
}
let toastT = 0;
function toast(s, ms) { const t = $('toast'); t.textContent = s; t.style.display = 'block'; clearTimeout(toastT); toastT = setTimeout(() => (t.style.display = 'none'), ms || 1800); }
function modal(html) { $('mbox').innerHTML = html; $('modal').classList.add('show'); }
function closeModal() { $('modal').classList.remove('show'); }
$('modal').addEventListener('pointerdown', (e) => { if (e.target === $('modal') && !recording) closeModal(); });
