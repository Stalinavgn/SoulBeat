// SoulBeat engine: patterns -> baked primitives, and the simulator that plays them.
// The Lua runtime (runtime.lua) mirrors Sim.step / soulStep / arenaAt exactly.
(function (G) {
  'use strict';
  const DEG = Math.PI / 180;
  const PR = 3; // player hit radius

  function mkrng(seed) {
    let s = (seed >>> 0) || 1;
    return function () {
      s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0;
      return s / 4294967296;
    };
  }
  const r2 = (v) => Math.round(v * 100) / 100;
  const r3 = (v) => Math.round(v * 1000) / 1000;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  // ---------- sprites ----------
  const SPR = {
    bullet: { name: 'Bullet', w: 16, h: 16, sh: 0, hr: 6 },
    dot: { name: 'Dot', w: 8, h: 8, sh: 0, hr: 3 },
    big: { name: 'Orb', w: 32, h: 32, sh: 0, hr: 13 },
    ring: { name: 'Ring', w: 24, h: 24, sh: 0, hr: 10 },
    star: { name: 'Star', w: 24, h: 24, sh: 0, hr: 7 },
    diamond: { name: 'Diamond', w: 16, h: 16, sh: 0, hr: 5 },
    knife: { name: 'Knife', w: 28, h: 10, sh: 1, hw: 12, hh: 3, dir: 1 },
    tri: { name: 'Arrow', w: 16, h: 16, sh: 0, hr: 5, dir: 1 },
    note: { name: 'Note', w: 16, h: 24, sh: 0, hr: 6 },
    heart: { name: 'Heart', w: 16, h: 16, sh: 0, hr: 6 },
    square: { name: 'Square', w: 12, h: 12, sh: 1, hw: 5, hh: 5 },
    px: { name: 'Pixel', w: 4, h: 4, sh: 1, hw: 2, hh: 2, hidden: 1 },
    spade: { name: 'Spade', g: 'dr', w: 24, h: 24, sh: 0, hr: 8 },
    scythe: { name: 'Scythe', g: 'dr', w: 32, h: 32, sh: 0, hr: 11 },
    egg: { name: 'Egg bomb', g: 'dr', w: 16, h: 20, sh: 0, hr: 7 },
    gear: { name: 'Gear', g: 'robo', w: 24, h: 24, sh: 0, hr: 9 },
    bolt: { name: 'Lightning bolt', g: 'robo', w: 16, h: 28, sh: 1, hw: 4, hh: 11 },
    wing: { name: 'Wing', g: 'angel', w: 28, h: 20, sh: 0, hr: 8 },
    sparkle: { name: 'Holy sparkle', g: 'angel', w: 24, h: 24, sh: 0, hr: 6 },
    sword: { name: 'Sword', g: 'medieval', w: 36, h: 12, sh: 1, hw: 15, hh: 3, dir: 1 },
    shield: { name: 'Shield', g: 'medieval', w: 22, h: 26, sh: 0, hr: 9 },
    hex: { name: 'Hex cell', g: 'future', w: 24, h: 24, sh: 0, hr: 9 },
    chevron: { name: 'Plasma chevron', g: 'future', w: 20, h: 20, sh: 0, hr: 6, dir: 1 },
    flame: { name: 'Flame', g: 'hell', w: 18, h: 26, sh: 0, hr: 7 },
    skull: { name: 'Skull', g: 'hell', w: 22, h: 24, sh: 0, hr: 9 },
    leaf: { name: 'Leaf', g: 'druid', w: 26, h: 14, sh: 1, hw: 10, hh: 4, dir: 1 },
    mushroom: { name: 'Mushroom', g: 'druid', w: 22, h: 22, sh: 0, hr: 8 },
  };
  const SPRG = [['basic', 'Classic'], ['dr', 'Dark world'], ['robo', 'RoboPunk'], ['angel', 'AngelPunk'], ['medieval', 'MedievalPunk'], ['future', 'FuturePunk'], ['hell', 'HellPunk'], ['druid', 'DruidPunk']];
  function spriteInfo(name, assets) {
    if (SPR[name]) return SPR[name];
    if (name && name.indexOf('bone_') === 0) {
      const h = +name.slice(5);
      return { w: 10, h: h, sh: 1, hw: 4, hh: Math.max(2, h / 2 - 1) };
    }
    if (assets) {
      for (const a of assets) if (a.id === name && a.kind === 'image')
        return { w: a.w, h: a.h, sh: 1, hw: a.w * 0.4, hh: a.h * 0.4, asset: 1 };
    }
    return SPR.bullet;
  }

  const TYCOL = [[1, 1, 1], [0.08, 0.66, 1], [1, 0.63, 0.25], [0.2, 1, 0.3], [1, 1, 1]];
  const TYPES = [['0', 'White — always hurts'], ['1', 'Cyan — hurts if you move'], ['2', 'Orange — hurts if you stand still'], ['3', 'Green — heals'], ['4', 'Decor — harmless']];
  const EVERY = [['0', 'Once'], ['4', 'Every 4 beats'], ['2', 'Every 2 beats'], ['1', 'Every beat'], ['0.5', 'Every 1/2 beat'], ['0.3333', 'Triplets (1/3)'], ['0.25', 'Every 1/4 beat'], ['0.125', 'Every 1/8 beat']];
  const SIDES = [['top', 'From the top'], ['bottom', 'From the bottom'], ['left', 'From the left'], ['right', 'From the right']];
  const EASE = [['1', 'Smooth'], ['0', 'Linear'], ['2', 'Dash and brake'], ['3', 'Instant']];

  function hexToRgb(h) {
    if (!h || h[0] !== '#') return null;
    const n = parseInt(h.slice(1), 16);
    return [r3(((n >> 16) & 255) / 255), r3(((n >> 8) & 255) / 255), r3((n & 255) / 255)];
  }

  // common bullet params appended to bullet patterns
  function BP(defSpr) {
    return [
      { k: 'spr', label: 'Bullet picture', type: 'sprite', def: defSpr || 'bullet' },
      { k: 'btype', label: 'Bullet type', type: 'sel', opts: TYPES, def: '0' },
      { k: 'col', label: 'Custom colour', type: 'color', def: '' },
      { k: 'size', label: 'Size', type: 'num', min: 0.25, max: 5, step: 0.25, def: 1 },
    ];
  }
  const P_EVERY = (def) => ({ k: 'every', label: 'Rhythm', type: 'sel', opts: EVERY, def: def });
  const P_SEED = { k: 'seed', label: 'Random layout', type: 'seed', def: 1 };

  // ---------- pattern library ----------
  const PAT = {};
  const CATS = [['atk', 'Attacks'], ['dr', 'Deltarune-style'], ['spec', 'Special'], ['stage', 'Stage & effects']];

  function baseKind(c, p, over) {
    const info = c.spriteInfo(p.spr);
    const ty = +(p.btype || 0);
    const col = hexToRgb(p.col) || (info.asset ? (ty === 0 || ty === 4 ? [1, 1, 1] : TYCOL[ty]) : TYCOL[ty]);
    const size = +p.size || 1;
    const k = {
      spr: p.spr, c: col, ty: ty, sh: info.sh, hr: info.hr || 0, hw: info.hw || 0, hh: info.hh || 0,
      life: 5, warn: 0, wa: 0.4, fi: 0, fo: 0, s0: size, s1: size, gt: 0, sx: 1, sy: 1, bm: 0,
      spin: 0, face: info.dir ? 1 : 0, rot0: 0, acc: 0, gx: 0, gy: 0, amp: 0, frq: 0, rv: 0, w: 0,
      home: 0, aim: 0, atp: 0, abs: 0, a: 1, ra: 0, rf: 0,
    };
    if (over) for (const key in over) k[key] = over[key];
    return k;
  }
  function sideGeom(side, A, m) {
    const cw = A.w / 2, ch = A.h / 2;
    if (side === 'top') return { ox: 0, oy: ch + m, ux: 1, uy: 0, span: cw, dir: -90, depth: A.h };
    if (side === 'bottom') return { ox: 0, oy: -ch - m, ux: 1, uy: 0, span: cw, dir: 90, depth: A.h };
    if (side === 'left') return { ox: -cw - m, oy: 0, ux: 0, uy: 1, span: ch, dir: 0, depth: A.w };
    return { ox: cw + m, oy: 0, ux: 0, uy: 1, span: ch, dir: 180, depth: A.w };
  }

  function ringBake(cl, c) {
    const p = cl.p, n = Math.max(1, Math.round(p.count));
    const sp = Math.max(10, p.speed);
    const k = baseKind(c, p, { rv: sp, w: p.curve || 0, life: r2(Math.min(15, 420 / sp)), spin: p.spin || 0 });
    c.times(cl, p.every).forEach((t, i) => {
      const base = (p.rot || 0) + i * (p.twist || 0);
      for (let j = 0; j < n; j++) c.emit(k, t, p.x, p.y, 0, 0, p.r0 || 0, base + j * 360 / n);
    });
  }
  PAT.ring = {
    name: 'Ring', cat: 'atk', icon: '◎', color: '#ff5d73', dur: 4,
    hint: 'Bullets fly out in a circle from a point. You can drag the point right on the battle screen.',
    params: [
      { k: 'pos', label: 'Centre', type: 'pos', def: [0, 0] },
      { k: 'count', label: 'Bullets per ring', type: 'num', min: 1, max: 64, step: 1, def: 12 },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 500, step: 5, def: 110 },
      P_EVERY('1'),
      { k: 'twist', label: 'Turn per volley°', type: 'num', min: -90, max: 90, step: 1, def: 15 },
      { k: 'curve', label: 'Curl°/s', type: 'num', min: -360, max: 360, step: 5, def: 0 },
      { k: 'r0', label: 'Start radius', type: 'num', min: 0, max: 300, step: 5, def: 0 },
    ].concat(BP('bullet')),
    bake: ringBake,
  };
  PAT.spiral = {
    name: 'Spiral', cat: 'atk', icon: '🌀', color: '#c77dff', dur: 8,
    hint: 'A continuous rotating stream. Play with “turn” and “arms” to get flowers and galaxies.',
    params: [
      { k: 'pos', label: 'Centre', type: 'pos', def: [0, 0] },
      { k: 'count', label: 'Arms', type: 'num', min: 1, max: 12, step: 1, def: 3 },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 500, step: 5, def: 100 },
      P_EVERY('0.25'),
      { k: 'twist', label: 'Turn per volley°', type: 'num', min: -90, max: 90, step: 1, def: 13 },
      { k: 'curve', label: 'Curl°/s', type: 'num', min: -360, max: 360, step: 5, def: 0 },
      { k: 'r0', label: 'Start radius', type: 'num', min: 0, max: 300, step: 5, def: 0 },
    ].concat(BP('dot')),
    bake: ringBake,
  };
  PAT.aimed = {
    name: 'Aimed shot', cat: 'atk', icon: '➹', color: '#ff9f1c', dur: 4,
    hint: 'Bullets fly to where the heart is right now. “Wind-up”: the bullet appears first and launches on the beat.',
    params: [
      { k: 'from', label: 'From', type: 'sel', opts: [['pos', 'From a point'], ['circle', 'Randomly around the arena']], def: 'pos' },
      { k: 'pos', label: 'Dot', type: 'pos', def: [0, 110] },
      { k: 'count', label: 'Bullets per volley', type: 'num', min: 1, max: 15, step: 1, def: 3 },
      { k: 'spread', label: 'Fan spread°', type: 'num', min: 0, max: 90, step: 1, def: 18 },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 600, step: 5, def: 190 },
      P_EVERY('1'),
      { k: 'warnb', label: 'Wind-up (beats)', type: 'num', min: 0, max: 4, step: 0.25, def: 0 },
      P_SEED,
    ].concat(BP('knife')),
    bake(cl, c) {
      const p = cl.p, n = Math.max(1, Math.round(p.count)), sp = Math.max(10, p.speed);
      const warn = r2((p.warnb || 0) * c.beat);
      const k = baseKind(c, p, { aim: 1, warn: warn, wa: 0.6, fi: 0.1, life: r2(warn + Math.min(12, 620 / sp)) });
      c.times(cl, p.every).forEach((t) => {
        let ox = p.x, oy = p.y;
        if (p.from === 'circle') {
          const A = c.arenaAt(t), a = c.rnd() * Math.PI * 2, R = Math.max(A.w, A.h) / 2 + 50;
          ox = Math.cos(a) * R; oy = Math.sin(a) * R;
        }
        for (let j = 0; j < n; j++) c.emit(k, t - warn, ox, oy, (j - (n - 1) / 2) * p.spread, sp, 0, 0);
      });
    },
  };
  PAT.rain = {
    name: 'Rain', cat: 'atk', icon: '☔', color: '#4cc9f0', dur: 8,
    hint: 'Bullets pour in from the chosen side at random spots.',
    params: [
      { k: 'side', label: 'From', type: 'sel', opts: SIDES, def: 'top' },
      { k: 'count', label: 'Bullets at once', type: 'num', min: 1, max: 12, step: 1, def: 1 },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 500, step: 5, def: 130 },
      P_EVERY('0.25'),
      { k: 'drift', label: 'Slant°', type: 'num', min: -60, max: 60, step: 1, def: 0 },
      { k: 'accel', label: 'Acceleration', type: 'num', min: -200, max: 600, step: 10, def: 0 },
      P_SEED,
    ].concat(BP('bullet')),
    bake(cl, c) {
      const p = cl.p, sp = Math.max(10, p.speed), n = Math.max(1, Math.round(p.count));
      c.times(cl, p.every).forEach((t) => {
        const g = sideGeom(p.side, c.arenaAt(t), 24);
        const k = baseKind(c, p, { acc: p.accel || 0, life: r2(Math.min(14, (g.depth + 120) / sp + 0.3)), fi: 0.1 });
        for (let j = 0; j < n; j++) {
          const u = (c.rnd() * 2 - 1) * (g.span - 4);
          c.emit(k, t, g.ox + g.ux * u, g.oy + g.uy * u, g.dir + (p.drift || 0), sp, 0, 0);
        }
      });
    },
  };
  PAT.wall = {
    name: 'Wall with a gap', cat: 'atk', icon: '▤', color: '#f72585', dur: 8,
    hint: 'A solid wall of bullets with one hole — get to the gap in time.',
    params: [
      { k: 'side', label: 'From', type: 'sel', opts: SIDES, def: 'right' },
      { k: 'gap', label: 'Gap width', type: 'num', min: 16, max: 200, step: 2, def: 40 },
      { k: 'gapmode', label: 'Gap position', type: 'sel', opts: [['rand', 'Random'], ['sweep', 'Drifts smoothly'], ['zig', 'Zigzag'], ['center', 'Centred']], def: 'rand' },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 500, step: 5, def: 120 },
      P_EVERY('2'),
      { k: 'step', label: 'Density (step)', type: 'num', min: 8, max: 40, step: 1, def: 14 },
      P_SEED,
    ].concat(BP('bullet')),
    bake(cl, c) {
      const p = cl.p, sp = Math.max(10, p.speed);
      c.times(cl, p.every).forEach((t, i) => {
        const g = sideGeom(p.side, c.arenaAt(t), 20);
        const k = baseKind(c, p, { life: r2(Math.min(14, (g.depth + 80) / sp + 0.3)), fi: 0.1 });
        const room = Math.max(0, g.span - p.gap / 2 - 4);
        let gc = 0;
        if (p.gapmode === 'rand') gc = (c.rnd() * 2 - 1) * room;
        else if (p.gapmode === 'sweep') gc = Math.sin(i * 0.9) * room;
        else if (p.gapmode === 'zig') gc = (i % 2 ? 1 : -1) * room * 0.8;
        const st = Math.max(6, p.step);
        for (let u = -g.span + st / 2; u < g.span; u += st) {
          if (Math.abs(u - gc) < p.gap / 2) continue;
          c.emit(k, t, g.ox + g.ux * u, g.oy + g.uy * u, g.dir, sp, 0, 0);
        }
      });
    },
  };
  PAT.bones = {
    name: 'Bones', cat: 'atk', icon: '🦴', color: '#e9ecef', dur: 8,
    hint: 'Bones slide along the floor or ceiling. Best with the blue soul (the “Soul” block) — you jump over them.',
    params: [
      { k: 'side', label: 'From', type: 'sel', opts: [['right', 'From the right'], ['left', 'From the left'], ['both', 'From both sides']], def: 'right' },
      { k: 'mode', label: 'Bone placement', type: 'sel', opts: [['floor', 'On the floor'], ['ceil', 'On the ceiling'], ['alt', 'Alternate'], ['corr', 'Corridor (floor + ceiling)'], ['rand', 'Random']], def: 'floor' },
      { k: 'hgt', label: 'Bone height, %', type: 'num', min: 10, max: 90, step: 5, def: 30 },
      { k: 'gap', label: 'Corridor gap', type: 'num', min: 20, max: 120, step: 2, def: 44 },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 500, step: 5, def: 130 },
      P_EVERY('1'),
      P_SEED,
      { k: 'btype', label: 'Type', type: 'sel', opts: TYPES, def: '0' },
      { k: 'col', label: 'Custom colour', type: 'color', def: '' },
    ],
    bake(cl, c) {
      const p = cl.p, sp = Math.max(10, p.speed);
      c.times(cl, p.every).forEach((t, i) => {
        const A = c.arenaAt(t), cw = A.w / 2, ch = A.h / 2;
        const q = (h) => clamp(Math.round(h / 10) * 10, 10, Math.max(10, Math.floor(A.h / 10) * 10));
        const list = []; // [height, isCeil]
        let m = p.mode;
        if (m === 'alt') m = i % 2 ? 'ceil' : 'floor';
        if (m === 'rand') m = c.rnd() < 0.5 ? 'ceil' : 'floor';
        let h = q(A.h * p.hgt / 100);
        if (p.mode === 'rand') h = q(A.h * (0.15 + c.rnd() * 0.45));
        if (m === 'floor') list.push([h, 0]);
        else if (m === 'ceil') list.push([h, 1]);
        else {
          let hf = h;
          if (p.mode === 'corr') hf = q(10 + ((Math.sin(i * 1.3) + 1) / 2) * (A.h - p.gap - 20));
          const hc = q(A.h - hf - p.gap);
          list.push([hf, 0]); if (A.h - hf - p.gap >= 10) list.push([hc, 1]);
        }
        const sides = p.side === 'both' ? ['left', 'right'] : [p.side];
        for (const sd of sides) for (const b of list) {
          const k = baseKind(c, { spr: 'bone_' + b[0], btype: p.btype, col: p.col, size: 1 }, { life: r2(Math.min(14, (A.w + 40) / sp + 0.2)), fi: 0.08 });
          const y = b[1] ? ch - b[0] / 2 : -ch + b[0] / 2;
          c.emit(k, t, sd === 'left' ? -cw - 12 : cw + 12, y, sd === 'left' ? 0 : 180, sp, 0, 0);
        }
      });
    },
  };
  PAT.laser = {
    name: 'Laser', cat: 'atk', icon: '⚡', color: '#ffe14d', dur: 4,
    hint: 'A thin warning line first, then the strike — the strike lands exactly on the beat.',
    params: [
      { k: 'orient', label: 'Direction', type: 'sel', opts: [['h', 'Horizontal'], ['v', 'Vertical'], ['alt', 'Alternate'], ['soul', 'Through the soul'], ['free', 'Custom angle and point']], def: 'alt' },
      { k: 'place', label: 'Placement', type: 'sel', opts: [['rand', 'Random'], ['sweep', 'Sweeps'], ['soul', 'On the soul']], def: 'soul' },
      { k: 'pos', label: 'Point (for custom angle)', type: 'pos', def: [0, 0] },
      { k: 'angle', label: 'Angle°', type: 'num', min: 0, max: 180, step: 5, def: 45 },
      { k: 'width', label: 'Thickness', type: 'num', min: 4, max: 120, step: 2, def: 22 },
      { k: 'warnb', label: 'Warning (beats)', type: 'num', min: 0.25, max: 4, step: 0.25, def: 1 },
      { k: 'holdb', label: 'Strike lasts (beats)', type: 'num', min: 0.1, max: 4, step: 0.05, def: 0.35 },
      P_EVERY('2'),
      P_SEED,
      { k: 'btype', label: 'Type', type: 'sel', opts: TYPES, def: '0' },
      { k: 'col', label: 'Custom colour', type: 'color', def: '' },
    ],
    bake(cl, c) {
      const p = cl.p, warn = r2(p.warnb * c.beat), hold = r2(Math.max(0.05, p.holdb * c.beat));
      c.times(cl, p.every).forEach((t, i) => {
        const A = c.arenaAt(t);
        let o = p.orient; if (o === 'alt') o = i % 2 ? 'v' : 'h';
        let x = 0, y = 0, ang = 0, atp = 0;
        const pl = (half) => p.place === 'rand' ? (c.rnd() * 2 - 1) * (half - 6) : p.place === 'sweep' ? Math.sin(i * 0.8) * (half - 8) : 0;
        if (o === 'h') { ang = 0; y = pl(A.h / 2); if (p.place === 'soul') atp = 1; }
        else if (o === 'v') { ang = 90; x = pl(A.w / 2); if (p.place === 'soul') atp = 1; }
        else if (o === 'soul') { atp = 1; ang = Math.round(c.rnd() * 180); }
        else { x = p.x; y = p.y; ang = p.angle; }
        const k = baseKind(c, { spr: 'px', btype: p.btype, col: p.col, size: 1 }, {
          sh: 1, hw: 480, hh: p.width / 2, sx: 240, sy: r2(p.width / 4), bm: 1, face: 2,
          warn: warn, wa: 0.45, life: r2(warn + hold), atp: atp,
        });
        c.emit(k, t - warn, x, y, ang, 0, 0, 0);
      });
    },
  };
  PAT.orbit = {
    name: 'Spinning cross', cat: 'atk', icon: '✚', color: '#80ed99', dur: 8,
    hint: 'Beams of bullets spin around a point for as long as the block lasts.',
    params: [
      { k: 'pos', label: 'Centre', type: 'pos', def: [0, 0] },
      { k: 'arms', label: 'Beams', type: 'num', min: 1, max: 12, step: 1, def: 4 },
      { k: 'n', label: 'Bullets per beam', type: 'num', min: 1, max: 20, step: 1, def: 6 },
      { k: 'gapr', label: 'Bullet spacing', type: 'num', min: 6, max: 60, step: 1, def: 16 },
      { k: 'inner', label: 'Empty centre', type: 'num', min: 0, max: 200, step: 2, def: 14 },
      { k: 'speed', label: 'Spin speed°/s', type: 'num', min: -360, max: 360, step: 5, def: 70 },
      { k: 'rot', label: 'Start angle°', type: 'num', min: 0, max: 360, step: 5, def: 0 },
      { k: 'breath', label: 'Expansion px/s', type: 'num', min: -60, max: 60, step: 1, def: 0 },
    ].concat(BP('bullet')),
    bake(cl, c) {
      const p = cl.p;
      const k = baseKind(c, p, { w: p.speed, rv: p.breath || 0, life: r2(cl.d), warn: 0.45, wa: 0.45, fi: 0.2, fo: 0.2 });
      for (let a = 0; a < Math.round(p.arms); a++)
        for (let j = 0; j < Math.round(p.n); j++)
          c.emit(k, cl.t, p.x, p.y, 0, 0, p.inner + j * p.gapr, (p.rot || 0) + a * 360 / Math.round(p.arms));
    },
  };
  PAT.sine = {
    name: 'Snake', cat: 'atk', icon: '〰', color: '#00f5d4', dur: 8,
    hint: 'Bullets travel in a wave, like a snake. Several streams make corridors.',
    params: [
      { k: 'side', label: 'From', type: 'sel', opts: SIDES, def: 'left' },
      { k: 'streams', label: 'Streams', type: 'num', min: 1, max: 6, step: 1, def: 2 },
      { k: 'amp', label: 'Wave size', type: 'num', min: 0, max: 100, step: 1, def: 22 },
      { k: 'frq', label: 'Waves per second', type: 'num', min: 0.1, max: 6, step: 0.1, def: 1.2 },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 400, step: 5, def: 100 },
      P_EVERY('0.25'),
      { k: 'mirror', label: 'Mirror streams', type: 'bool', def: true },
    ].concat(BP('dot')),
    bake(cl, c) {
      const p = cl.p, sp = Math.max(10, p.speed), n = Math.max(1, Math.round(p.streams));
      c.times(cl, p.every).forEach((t) => {
        const g = sideGeom(p.side, c.arenaAt(t), 20);
        for (let j = 0; j < n; j++) {
          const u = n === 1 ? 0 : (-1 + (2 * (j + 0.5)) / n) * g.span;
          const k = baseKind(c, p, { amp: (p.mirror && j % 2 ? -1 : 1) * p.amp, frq: p.frq, life: r2(Math.min(14, (g.depth + 80) / sp + 0.3)), fi: 0.1 });
          c.emit(k, t, g.ox + g.ux * u, g.oy + g.uy * u, g.dir, sp, 0, 0);
        }
      });
    },
  };
  PAT.homing = {
    name: 'Chasers', cat: 'atk', icon: '👁', color: '#ff6b6b', dur: 4,
    hint: 'Bullets steer after the heart. The more “agility”, the meaner.',
    params: [
      { k: 'count', label: 'Count at once', type: 'num', min: 1, max: 8, step: 1, def: 1 },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 300, step: 5, def: 85 },
      { k: 'turn', label: 'Agility°/s', type: 'num', min: 10, max: 400, step: 5, def: 110 },
      { k: 'lifeb', label: 'Lifetime (beats)', type: 'num', min: 1, max: 32, step: 1, def: 8 },
      P_EVERY('2'),
      P_SEED,
    ].concat(BP('big')),
    bake(cl, c) {
      const p = cl.p;
      const k = baseKind(c, p, { home: p.turn, aim: 1, life: r2(p.lifeb * c.beat), fi: 0.25, fo: 0.3, warn: 0.25, wa: 0.6 });
      c.times(cl, p.every).forEach((t) => {
        const A = c.arenaAt(t), R = Math.max(A.w, A.h) / 2 + 40;
        for (let j = 0; j < Math.round(p.count); j++) {
          const a = c.rnd() * Math.PI * 2;
          c.emit(k, t, Math.cos(a) * R, Math.sin(a) * R, 0, Math.max(10, p.speed), 0, 0);
        }
      });
    },
  };
  PAT.fountain = {
    name: 'Fountain', cat: 'atk', icon: '⛲', color: '#90e0ef', dur: 4,
    hint: 'Bullets shoot up and fall in an arc under gravity.',
    params: [
      { k: 'pos', label: 'From', type: 'pos', def: [0, -75] },
      { k: 'count', label: 'Bullets per volley', type: 'num', min: 1, max: 24, step: 1, def: 5 },
      { k: 'spread', label: 'Spread°', type: 'num', min: 0, max: 180, step: 2, def: 50 },
      { k: 'power', label: 'Power', type: 'num', min: 40, max: 600, step: 5, def: 230 },
      { k: 'grav', label: 'Gravity', type: 'num', min: 50, max: 1200, step: 10, def: 380 },
      { k: 'dir', label: 'Direction°', type: 'num', min: 0, max: 360, step: 5, def: 90 },
      P_EVERY('1'),
      P_SEED,
    ].concat(BP('bullet')),
    bake(cl, c) {
      const p = cl.p, gr = Math.max(10, p.grav);
      c.times(cl, p.every).forEach((t) => {
        for (let j = 0; j < Math.round(p.count); j++) {
          const sp = r2(p.power * (0.75 + 0.5 * c.rnd()));
          const k = baseKind(c, p, { gy: -gr, life: r2(Math.min(8, (2.5 * p.power) / gr + 1.2)), face: 1 });
          c.emit(k, t, p.x, p.y, p.dir + (c.rnd() - 0.5) * p.spread, sp, 0, 0);
        }
      });
    },
  };
  PAT.mines = {
    name: 'Flash mines', cat: 'atk', icon: '✸', color: '#fca311', dur: 4,
    hint: 'Marks appear in the arena and “explode” exactly on the beat.',
    params: [
      { k: 'place', label: 'Where', type: 'sel', opts: [['rand', 'Random in the arena'], ['soul', 'Under the soul'], ['grid', 'Checkerboard']], def: 'rand' },
      { k: 'count', label: 'Count at once', type: 'num', min: 1, max: 24, step: 1, def: 3 },
      { k: 'warnb', label: 'Warning (beats)', type: 'num', min: 0.25, max: 4, step: 0.25, def: 1 },
      { k: 'holdb', label: 'Explosion lasts (beats)', type: 'num', min: 0.1, max: 4, step: 0.05, def: 0.4 },
      P_EVERY('1'),
      P_SEED,
    ].concat(BP('big')),
    bake(cl, c) {
      const p = cl.p, warn = r2(p.warnb * c.beat), hold = r2(Math.max(0.05, p.holdb * c.beat));
      const sz = +p.size || 1;
      c.times(cl, p.every).forEach((t, i) => {
        const A = c.arenaAt(t);
        const k = baseKind(c, p, { warn: warn, wa: 0.4, life: r2(warn + hold), s0: r2(sz * 0.35), s1: sz, gt: warn, fo: 0.12, atp: p.place === 'soul' ? 1 : 0 });
        if (p.place === 'grid') {
          const cols = Math.max(2, Math.round(A.w / 36)), rows = Math.max(2, Math.round(A.h / 36));
          for (let a = 0; a < cols; a++) for (let b = 0; b < rows; b++) {
            if ((a + b + i) % 2) continue;
            c.emit(k, t - warn, -A.w / 2 + (a + 0.5) * A.w / cols, -A.h / 2 + (b + 0.5) * A.h / rows, 0, 0, 0, 0);
          }
          return;
        }
        for (let j = 0; j < Math.round(p.count); j++) {
          if (p.place === 'soul') c.emit(k, t - warn, j ? (c.rnd() - 0.5) * 60 : 0, j ? (c.rnd() - 0.5) * 60 : 0, 0, 0, 0, 0);
          else c.emit(k, t - warn, (c.rnd() - 0.5) * (A.w - 20), (c.rnd() - 0.5) * (A.h - 20), 0, 0, 0, 0);
        }
      });
    },
  };
  PAT.cage = {
    name: 'Closing cage', cat: 'dr', icon: '♠', color: '#b388ff', dur: 8,
    hint: 'A ring of bullets appears around the soul and closes in — slip out through the gap before it shuts. In the spirit of the chaos jester and the spade king.',
    params: [
      { k: 'target', label: 'Centre of the ring', type: 'sel', opts: [['soul', 'On the soul'], ['center', 'Arena centre']], def: 'soul' },
      { k: 'count', label: 'Bullets per ring', type: 'num', min: 6, max: 48, step: 1, def: 18 },
      { k: 'gapn', label: 'Gap (missing bullets)', type: 'num', min: 1, max: 12, step: 1, def: 3 },
      { k: 'radius', label: 'Start radius', type: 'num', min: 50, max: 300, step: 5, def: 140 },
      { k: 'closeb', label: 'Closes in (beats)', type: 'num', min: 0.5, max: 8, step: 0.25, def: 3 },
      { k: 'rotsp', label: 'Spin speed°/s', type: 'num', min: -360, max: 360, step: 5, def: 50 },
      P_EVERY('4'),
      P_SEED,
    ].concat(BP('spade')),
    bake(cl, c) {
      const p = cl.p, n = Math.max(3, Math.round(p.count)), close = Math.max(0.2, p.closeb * c.beat), warn = r2(Math.min(0.35, close / 3));
      const k = baseKind(c, p, { rv: r2(-(p.radius - 4) / close), w: p.rotsp, life: r2(warn + close), warn: warn, wa: 0.5, fi: 0.2, atp: p.target === 'soul' ? 1 : 0 });
      c.times(cl, p.every).forEach((t) => {
        const g0 = Math.floor(c.rnd() * n), gn = Math.min(n - 1, Math.round(p.gapn));
        for (let j = 0; j < n; j++) { if ((j - g0 + n) % n < gn) continue; c.emit(k, t, 0, 0, 0, 0, p.radius, j * 360 / n); }
      });
    },
  };
  PAT.scythe = {
    name: 'Spinning scythes', cat: 'dr', icon: '☾', color: '#7b2cbf', dur: 8,
    hint: 'Big blades whirl around a point, swinging in and out. Anything can happen — find the rhythm of the swing and dance between them.',
    params: [
      { k: 'pos', label: 'Centre', type: 'pos', def: [0, 0] },
      { k: 'count', label: 'Blades', type: 'num', min: 1, max: 8, step: 1, def: 2 },
      { k: 'radius', label: 'Orbit radius', type: 'num', min: 0, max: 250, step: 5, def: 75 },
      { k: 'swing', label: 'Swing in/out', type: 'num', min: 0, max: 150, step: 5, def: 45 },
      { k: 'swingf', label: 'Swings per second', type: 'num', min: 0.05, max: 4, step: 0.05, def: 0.5 },
      { k: 'speed', label: 'Orbit speed°/s', type: 'num', min: -360, max: 360, step: 5, def: 110 },
      { k: 'spin', label: 'Blade spin°/s', type: 'num', min: -1440, max: 1440, step: 10, def: 540 },
      { k: 'rot', label: 'Start angle°', type: 'num', min: 0, max: 360, step: 5, def: 0 },
      { k: 'spr', label: 'Bullet picture', type: 'sprite', def: 'scythe' },
      { k: 'btype', label: 'Bullet type', type: 'sel', opts: TYPES, def: '0' },
      { k: 'col', label: 'Custom colour', type: 'color', def: '' },
      { k: 'size', label: 'Size', type: 'num', min: 0.25, max: 5, step: 0.25, def: 1.5 },
    ],
    bake(cl, c) {
      const p = cl.p, n = Math.max(1, Math.round(p.count));
      const k = baseKind(c, p, { w: p.speed, ra: p.swing, rf: p.swingf, spin: p.spin, face: 0, life: r2(cl.d), warn: 0.45, wa: 0.45, fi: 0.2, fo: 0.2 });
      for (let j = 0; j < n; j++) c.emit(k, cl.t, p.x, p.y, 0, 0, p.radius, (p.rot || 0) + j * 360 / n);
    },
  };
  PAT.bomb = {
    name: 'Egg bombs', cat: 'dr', icon: '🥚', color: '#f1fa8c', dur: 8,
    hint: 'A bomb drops onto a marked spot and bursts into a ring of bullets exactly on the beat. A big-shot salesman would be proud.',
    params: [
      { k: 'count', label: 'Bombs at once', type: 'num', min: 1, max: 6, step: 1, def: 1 },
      { k: 'fallb', label: 'Fall time (beats)', type: 'num', min: 0.25, max: 4, step: 0.25, def: 1 },
      { k: 'burst', label: 'Bullets per burst', type: 'num', min: 3, max: 32, step: 1, def: 8 },
      { k: 'speed', label: 'Speed', type: 'num', min: 20, max: 400, step: 5, def: 120 },
      P_EVERY('2'),
      P_SEED,
      { k: 'bspr', label: 'Bomb picture', type: 'sprite', def: 'egg' },
    ].concat(BP('bullet')),
    bake(cl, c) {
      const p = cl.p, fall = r2(Math.max(0.1, p.fallb * c.beat)), sp = Math.max(10, p.speed), nb = Math.max(3, Math.round(p.burst));
      const kEgg = baseKind(c, { spr: p.bspr, btype: '0', col: '', size: 1 }, { life: fall, fi: 0.1, spin: 300, face: 0 });
      const kMark = baseKind(c, { spr: 'ring', btype: '4', col: '', size: 1 }, { life: fall, a: 0.5, s0: 1.5, s1: 0.6, gt: fall });
      const kB = baseKind(c, p, { rv: sp, life: r2(Math.min(12, 420 / sp)) });
      c.times(cl, p.every).forEach((t) => {
        const A = c.arenaAt(t);
        for (let j = 0; j < Math.round(p.count); j++) {
          const x = r2((c.rnd() - 0.5) * (A.w - 24)), y = r2((c.rnd() - 0.5) * (A.h - 24)), H = A.h / 2 + 50 - y, off = c.rnd() * 360;
          c.emit(kMark, t - fall, x, y, 0, 0, 0, 0);
          c.emit(kEgg, t - fall, x, y + H, -90, H / fall, 0, 0);
          for (let i = 0; i < nb; i++) c.emit(kB, t, x, y, 0, 0, 0, off + i * 360 / nb);
        }
      });
    },
  };
  PAT.slash = {
    name: 'Cross slash', cat: 'dr', icon: '✖', color: '#ff4d6d', dur: 8,
    hint: 'Several thin lines cross at one point, then all of them cut at once on the beat. Like the sword strokes of a certain knight.',
    params: [
      { k: 'target', label: 'Where', type: 'sel', opts: [['soul', 'On the soul'], ['rand', 'Random in the arena'], ['center', 'Arena centre']], def: 'soul' },
      { k: 'lines', label: 'Cuts at once', type: 'num', min: 1, max: 6, step: 1, def: 2 },
      { k: 'width', label: 'Thickness', type: 'num', min: 4, max: 80, step: 2, def: 12 },
      { k: 'warnb', label: 'Warning (beats)', type: 'num', min: 0.25, max: 4, step: 0.25, def: 1 },
      { k: 'holdb', label: 'Strike lasts (beats)', type: 'num', min: 0.1, max: 4, step: 0.05, def: 0.25 },
      P_EVERY('2'),
      P_SEED,
      { k: 'btype', label: 'Type', type: 'sel', opts: TYPES, def: '0' },
      { k: 'col', label: 'Custom colour', type: 'color', def: '' },
    ],
    bake(cl, c) {
      const p = cl.p, warn = r2(p.warnb * c.beat), hold = r2(Math.max(0.05, p.holdb * c.beat)), n = Math.max(1, Math.round(p.lines));
      const k = baseKind(c, { spr: 'px', btype: p.btype, col: p.col, size: 1 }, {
        sh: 1, hw: 480, hh: p.width / 2, sx: 240, sy: r2(p.width / 4), bm: 1, face: 2, warn: warn, wa: 0.45, life: r2(warn + hold), atp: p.target === 'soul' ? 1 : 0,
      });
      c.times(cl, p.every).forEach((t) => {
        const A = c.arenaAt(t), base = Math.round(c.rnd() * 180);
        let x = 0, y = 0;
        if (p.target === 'rand') { x = r2((c.rnd() - 0.5) * (A.w - 20)); y = r2((c.rnd() - 0.5) * (A.h - 20)); }
        for (let j = 0; j < n; j++) c.emit(k, t - warn, x, y, base + j * 180 / n, 0, 0, 0);
      });
    },
  };
  PAT.object = {
    name: 'Custom object', cat: 'spec', icon: '🖼', color: '#b8f2e6', dur: 4,
    hint: 'A single picture: your asset or any bullet. Place it with the mouse, give it motion — it can be decoration or a dangerous thing.',
    params: [
      { k: 'spr', label: 'Picture', type: 'sprite', def: 'star' },
      { k: 'btype', label: 'Behaviour', type: 'sel', opts: TYPES, def: '4' },
      { k: 'pos', label: 'Position', type: 'pos', def: [0, 140] },
      { k: 'abs', label: 'Don\'t follow the arena', type: 'bool', def: false },
      { k: 'size', label: 'Start size', type: 'num', min: 0.1, max: 12, step: 0.1, def: 1 },
      { k: 'size1', label: 'End size', type: 'num', min: 0.1, max: 12, step: 0.1, def: 1 },
      { k: 'angle', label: 'Flies towards°', type: 'num', min: 0, max: 360, step: 5, def: 0 },
      { k: 'speed', label: 'Speed', type: 'num', min: 0, max: 600, step: 5, def: 0 },
      { k: 'accel', label: 'Acceleration', type: 'num', min: -400, max: 800, step: 10, def: 0 },
      { k: 'rot0', label: 'Slant°', type: 'num', min: 0, max: 360, step: 5, def: 0 },
      { k: 'spin', label: 'Spin°/s', type: 'num', min: -720, max: 720, step: 10, def: 0 },
      { k: 'wamp', label: 'Sway (size)', type: 'num', min: 0, max: 100, step: 1, def: 0 },
      { k: 'wfrq', label: 'Sways per second', type: 'num', min: 0.1, max: 6, step: 0.1, def: 1 },
      { k: 'alpha', label: 'Opacity', type: 'num', min: 0.05, max: 1, step: 0.05, def: 1 },
      { k: 'fi', label: 'Fade in, s', type: 'num', min: 0, max: 5, step: 0.05, def: 0.2 },
      { k: 'fo', label: 'Fade out, s', type: 'num', min: 0, max: 5, step: 0.05, def: 0.2 },
      { k: 'col', label: 'Recolour', type: 'color', def: '' },
    ],
    bake(cl, c) {
      const p = cl.p;
      let ang = p.angle, amp = p.wamp || 0;
      // "sway in place": zero speed + amp -> sway vertically around the spot
      const k = baseKind(c, p, {
        life: r2(cl.d), acc: p.accel || 0, spin: p.spin || 0, rot0: p.rot0 || 0, face: 0,
        s0: p.size, s1: p.size1, gt: p.size1 !== p.size ? r2(cl.d) : 0, a: p.alpha,
        fi: p.fi, fo: p.fo, abs: p.abs ? 1 : 0, amp: amp, frq: p.wfrq || 1,
      });
      const A = c.arenaAt(cl.t);
      const x = p.abs ? p.x + A.x : p.x, y = p.abs ? p.y + A.y + 5 + A.h / 2 : p.y;
      c.emit(k, cl.t, x, y, ang, p.speed, 0, 0);
    },
  };
  PAT.flash = {
    name: 'Screen flash', cat: 'stage', icon: '☀', color: '#ffffff', dur: 1,
    hint: 'The screen flashes with a colour and fades. Great on accents and drops.',
    params: [
      { k: 'col', label: 'Colour', type: 'color', def: '#ffffff', req: 1 },
      { k: 'alpha', label: 'Brightness', type: 'num', min: 0.05, max: 1, step: 0.05, def: 0.7 },
      { k: 'fadeb', label: 'Fades over (beats)', type: 'num', min: 0.1, max: 8, step: 0.1, def: 0.5 },
      P_EVERY('0'),
    ],
    bake(cl, c) {
      const p = cl.p, life = r2(Math.max(0.05, p.fadeb * c.beat));
      const k = baseKind(c, { spr: 'px', btype: '4', col: p.col || '#ffffff', size: 1 }, { sh: 1, hw: 400, hh: 300, sx: 200, sy: 150, abs: 1, life: life, fo: life, a: p.alpha });
      c.times(cl, p.every).forEach((t) => c.emit(k, t, 320, 240, 0, 0, 0, 0));
    },
  };
  PAT.shake = {
    name: 'Shake', cat: 'stage', icon: '〽', color: '#adb5bd', dur: 1,
    hint: 'The screen shakes. With the “every beat” rhythm you get a pumping pulse.',
    params: [
      { k: 'power', label: 'Power', type: 'num', min: 1, max: 30, step: 1, def: 5 },
      P_EVERY('0'),
      { k: 'lenb', label: 'Jolt length (beats)', type: 'num', min: 0.1, max: 4, step: 0.05, def: 0.4 },
    ],
    bake(cl, c) {
      const p = cl.p;
      if (p.every === '0') c.fx.push({ t: r3(cl.t), f: 1, a: Math.max(1, Math.round(cl.d * 60)), b: p.power });
      else c.times(cl, p.every).forEach((t) => c.fx.push({ t: r3(t), f: 1, a: Math.max(1, Math.round(p.lenb * c.beat * 60)), b: p.power }));
    },
  };
  PAT.arena = {
    name: 'Arena', cat: 'stage', icon: '⬚', color: '#e0e0e0', dur: 2,
    hint: 'Changes the size and place of the white box. Block length = how long the change takes.',
    params: [
      { k: 'w', label: 'Width', type: 'num', min: 20, max: 600, step: 5, def: 155 },
      { k: 'h', label: 'Height', type: 'num', min: 20, max: 400, step: 5, def: 130 },
      { k: 'ax', label: 'Centre X', type: 'num', min: 20, max: 620, step: 5, def: 320 },
      { k: 'ay', label: 'Box bottom Y', type: 'num', min: 0, max: 440, step: 5, def: 90 },
      { k: 'ease', label: 'Motion', type: 'sel', opts: EASE, def: '1' },
    ],
    bake() { },
  };
  PAT.acol = {
    name: 'Arena colour', cat: 'stage', icon: '🎨', color: '#f4a261', dur: 4,
    hint: 'Colours the arena border and inside while the block lasts.',
    params: [
      { k: 'col', label: 'Border', type: 'color', def: '#ffe14d', req: 1 },
      { k: 'fill', label: 'Inside', type: 'color', def: '#000000', req: 1 },
    ],
    bake(cl, c) {
      c.acol.push({ t0: r3(cl.t), t1: r3(cl.t + cl.d), o: hexToRgb(cl.p.col) || [1, 1, 1], i: hexToRgb(cl.p.fill) || [0, 0, 0] });
    },
  };
  PAT.soul = {
    name: 'Soul', cat: 'spec', icon: '♥', color: '#3a86ff', dur: 8,
    hint: 'While the block lasts the heart is blue: gravity pulls it and it jumps. Outside the block it is the usual red.',
    params: [
      { k: 'g', label: 'Gravity pulls', type: 'sel', opts: [['0', 'Down'], ['1', 'Up'], ['2', 'Left'], ['3', 'Right']], def: '0' },
    ],
    bake(cl, c) { c.soul.push({ t0: r3(cl.t), t1: r3(cl.t + cl.d), g: +cl.p.g }); },
  };
  PAT.sound = {
    name: 'Sound', cat: 'stage', icon: '🔊', color: '#9d4edd', dur: 1,
    hint: 'Plays a sound from your files (add it in the “Assets” tab).',
    params: [
      { k: 'snd', label: 'Sound', type: 'sound', def: '' },
      { k: 'vol', label: 'Volume', type: 'num', min: 0.05, max: 1, step: 0.05, def: 0.65 },
      P_EVERY('0'),
    ],
    bake(cl, c) {
      if (!cl.p.snd) return;
      c.times(cl, cl.p.every).forEach((t) => c.fx.push({ t: r3(t), f: 2, s: cl.p.snd, b: cl.p.vol }));
    },
  };

  function defaults(type) {
    const p = {};
    for (const d of PAT[type].params) {
      if (d.type === 'pos') { p.x = d.def[0]; p.y = d.def[1]; }
      else p[d.k] = d.def;
    }
    return p;
  }

  // ---------- arena ----------
  function ease(k, e) {
    if (e === 1) return k * k * (3 - 2 * k);
    if (e === 2) { const q = 1 - k; return 1 - q * q * q; }
    return k;
  }
  function arenaAtSegs(segs, init, t) {
    let s = null;
    for (let i = 0; i < segs.length; i++) { if (segs[i].t0 <= t) s = segs[i]; else break; }
    if (!s) return init;
    let k = s.t1 > s.t0 ? clamp((t - s.t0) / (s.t1 - s.t0), 0, 1) : 1;
    if (s.e === 3) k = 1;
    k = ease(k, s.e);
    return { x: s.fx + (s.tx - s.fx) * k, y: s.fy + (s.ty - s.fy) * k, w: s.fw + (s.tw - s.fw) * k, h: s.fh + (s.th - s.fh) * k };
  }

  // ---------- bake ----------
  function bake(proj) {
    const beat = 60 / (proj.bpm || 120);
    const st = proj.settings;
    const init = { x: st.arena.x, y: st.arena.y, w: st.arena.w, h: st.arena.h };
    const clips = proj.clips.filter((c) => PAT[c.type] && !c.off).slice().sort((a, b) => a.t - b.t || a.id - b.id);
    const segs = [];
    for (const cl of clips) if (cl.type === 'arena') {
      const f = arenaAtSegs(segs, init, cl.t);
      segs.push({ t0: r3(cl.t), t1: r3(cl.t + cl.d), fx: r2(f.x), fy: r2(f.y), fw: r2(f.w), fh: r2(f.h), tx: cl.p.ax, ty: cl.p.ay, tw: cl.p.w, th: cl.p.h, e: +cl.p.ease });
    }
    const kinds = [], kmap = new Map(), spawns = [];
    const B = { kinds, spawns, arena: segs, init, soul: [], acol: [], fx: [], dur: proj.duration, beat };
    let rnd = Math.random;
    const c = {
      beat, fx: B.fx, soul: B.soul, acol: B.acol,
      rnd: () => rnd(),
      arenaAt: (t) => arenaAtSegs(segs, init, t),
      spriteInfo: (n) => spriteInfo(n, proj.assets),
      times(cl, every) {
        const ev = +every, out = [];
        if (!ev) return [cl.t];
        const step = ev * beat;
        for (let i = 0; cl.t + i * step < cl.t + cl.d - 0.001 && i < 4000; i++) out.push(cl.t + i * step);
        return out;
      },
      emit(k, t, x, y, ang, spd, r0, a0) {
        if (t < 0) t = 0;
        if (t > proj.duration) return;
        const key = JSON.stringify(k);
        let id = kmap.get(key);
        if (id === undefined) { id = kinds.length; kinds.push(k); kmap.set(key, id); }
        spawns.push([r3(t), id, r2(x), r2(y), r2(ang), r2(spd), r2(r0), r2(a0)]);
      },
    };
    for (const cl of clips) {
      if (cl.type === 'arena') continue;
      rnd = mkrng(((proj.seed || 1) * 7919 + cl.id * 104729 + ((cl.p.seed || 1) * 15485863)) >>> 0);
      for (let i = 0; i < 5; i++) rnd();
      PAT[cl.type].bake(cl, c);
    }
    spawns.forEach((s, i) => (s._i = i));
    spawns.sort((a, b) => a[0] - b[0] || a._i - b._i);
    spawns.forEach((s) => delete s._i);
    B.fx.sort((a, b) => a.t - b.t);
    let ml = 0; const used = new Set();
    for (const k of kinds) { if (k.life > ml) ml = k.life; used.add(k.spr); }
    B.maxLife = ml; B.sprites = used;
    B.sounds = new Set(B.fx.filter((f) => f.f === 2).map((f) => f.s));
    return B;
  }

  // ---------- simulation (mirrored in Lua) ----------
  function wrapPi(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
  function kinPos(K, b, tau, out) {
    let d = b.spd * tau + 0.5 * K.acc * tau * tau;
    if (K.acc < 0 && b.spd > 0) { const ts = b.spd / -K.acc; if (tau > ts) d = b.spd * ts + 0.5 * K.acc * ts * ts; }
    const wv = K.amp !== 0 ? K.amp * Math.sin(2 * Math.PI * K.frq * tau) : 0;
    const ca = Math.cos(b.ang), sa = Math.sin(b.ang);
    let x = b.x + ca * d - sa * wv + 0.5 * K.gx * tau * tau;
    let y = b.y + sa * d + ca * wv + 0.5 * K.gy * tau * tau;
    const r = b.r0 + K.rv * tau + (K.ra !== 0 ? K.ra * Math.sin(2 * Math.PI * K.rf * tau) : 0);
    if (r !== 0) { const a = b.a0 + K.w * DEG * tau; x += r * Math.cos(a); y += r * Math.sin(a); }
    out.x = x; out.y = y;
  }

  class Sim {
    constructor(B) { this.B = B; this.live = []; this.i = 0; this.fi = 0; this.tmp = { x: 0, y: 0 }; }
    reset(t) {
      const S = this.B.spawns; let lo = 0, hi = S.length;
      while (lo < hi) { const m = (lo + hi) >> 1; if (S[m][0] < t) lo = m + 1; else hi = m; }
      this.i = lo; this.live.length = 0;
      const F = this.B.fx; let j = 0; while (j < F.length && F[j].t < t) j++; this.fi = j;
    }
    arena(t) { return arenaAtSegs(this.B.arena, this.B.init, t); }
    soulMode(t) { let m = null; for (const s of this.B.soul) if (s.t0 <= t && t < s.t1) m = s; return m; }
    acol(t) { let m = null; for (const s of this.B.acol) if (s.t0 <= t && t < s.t1) m = s; return m; }
    // P: {x,y,moving} absolute. onHit(b) called for touching bullets. onFx(fx) for events.
    step(t, dt, P, onHit, onFx) {
      const B = this.B, S = B.spawns, A = this.arena(t);
      const cx = A.x, cy = A.y + 5 + A.h / 2, tmp = this.tmp;
      if (onFx) while (this.fi < B.fx.length && B.fx[this.fi].t <= t) onFx(B.fx[this.fi++]);
      while (this.i < S.length && S[this.i][0] <= t) {
        const s = S[this.i++], K = B.kinds[s[1]];
        const ox = K.abs ? 0 : cx, oy = K.abs ? 0 : cy;
        let x = s[2], y = s[3], ang = s[4] * DEG;
        if (K.atp) { x += P.x - ox; y += P.y - oy; }
        if (K.aim) ang += Math.atan2(P.y - oy - y, P.x - ox - x);
        this.live.push({ K, t0: s[0], x, y, ang, spd: s[5], r0: s[6], a0: s[7] * DEG, hx: x, hy: y, lx: x + s[6] * Math.cos(s[7] * DEG), ly: y + s[6] * Math.sin(s[7] * DEG), head: ang, X: 0, Y: 0, rot: 0, al: 0, sc: 1, bf: 1, warn: false });
      }
      const L = this.live;
      for (let n = L.length - 1; n >= 0; n--) {
        const b = L[n], K = b.K, age = t - b.t0;
        if (age >= K.life || b.dead) { L[n] = L[L.length - 1]; L.pop(); continue; }
        const tau = age > K.warn ? age - K.warn : 0;
        const ox = K.abs ? 0 : cx, oy = K.abs ? 0 : cy;
        let px, py;
        if (K.home > 0) {
          if (tau > 0) {
            const des = Math.atan2(P.y - oy - b.hy, P.x - ox - b.hx);
            const d = wrapPi(des - b.ang), lim = K.home * DEG * dt;
            b.ang += clamp(d, -lim, lim);
            const v = Math.max(0, b.spd + K.acc * tau);
            b.hx += Math.cos(b.ang) * v * dt; b.hy += Math.sin(b.ang) * v * dt;
          }
          px = b.hx; py = b.hy;
        } else { kinPos(K, b, tau, tmp); px = tmp.x; py = tmp.y; }
        const ddx = px - b.lx, ddy = py - b.ly;
        if (ddx * ddx + ddy * ddy > 0.0001) b.head = Math.atan2(ddy, ddx);
        b.lx = px; b.ly = py;
        b.X = px + ox; b.Y = py + oy;
        b.rot = K.rot0 + K.spin * age + (K.face === 1 ? b.head / DEG : K.face === 2 ? b.ang / DEG : 0);
        b.sc = K.gt > 0 ? K.s0 + (K.s1 - K.s0) * Math.min(1, age / K.gt) : K.s0;
        let al = K.a;
        if (K.fi > 0) al *= Math.min(1, age / K.fi);
        if (K.fo > 0) al *= Math.min(1, (K.life - age) / K.fo);
        const inWarn = age < K.warn;
        if (inWarn) al *= K.wa;
        let bf = 1;
        if (K.bm) bf = inWarn ? 1 / K.hh : clamp(Math.min((age - K.warn) / 0.06, (K.life - age) / 0.1), 0, 1);
        b.al = al; b.bf = bf; b.warn = inWarn;
        if (onHit && !inWarn && K.ty !== 4 && al > 0.3 && bf > 0.5) {
          const dx = P.x - b.X, dy = P.y - b.Y;
          let hit;
          if (K.sh === 0) { const rr = K.hr * b.sc + PR; hit = dx * dx + dy * dy < rr * rr; }
          else {
            const r = b.rot * DEG, cr = Math.cos(r), sr = Math.sin(r);
            const lx = dx * cr + dy * sr, ly = -dx * sr + dy * cr;
            hit = Math.abs(lx) < K.hw * b.sc + PR && Math.abs(ly) < K.hh * b.sc * bf + PR;
          }
          if (hit) onHit(b);
        }
      }
    }
    // rebuild state at time t without side effects (for scrubbing)
    seek(t, P) {
      const t0 = Math.max(0, t - this.B.maxLife - 0.05);
      this.reset(t0);
      const dt = 1 / 60;
      for (let tt = t0; tt < t; tt += dt) this.step(tt, dt, P, null, null);
      this.step(t, dt, P, null, null);
      const F = this.B.fx; let j = 0; while (j < F.length && F[j].t < t) j++; this.fi = j;
    }
  }

  // soul physics. S: {x,y (rel. to arena centre), v, ground}. inp: {l,r,u,d,slow}
  const JUMP = 240, GUP = 480, GDN = 640;
  function soulStep(S, inp, dt, A, blue, g) {
    const sp = inp.slow ? 60 : 120;
    const hx = A.w / 2 - 8, hy = A.h / 2 - 8;
    if (!blue) {
      S.x += ((inp.r ? 1 : 0) - (inp.l ? 1 : 0)) * sp * dt;
      S.y += ((inp.u ? 1 : 0) - (inp.d ? 1 : 0)) * sp * dt;
      S.v = 0; S.ground = false;
    } else {
      // U = "up" (against gravity); free axis is perpendicular
      let ux = 0, uy = 1, jump = inp.u, free;
      if (g === 1) { uy = -1; jump = inp.d; } else if (g === 2) { ux = 1; uy = 0; jump = inp.r; } else if (g === 3) { ux = -1; uy = 0; jump = inp.l; }
      const ext = ux !== 0 ? hx : hy;
      if (ux === 0) { free = ((inp.r ? 1 : 0) - (inp.l ? 1 : 0)) * sp * dt; S.x += free; }
      else { free = ((inp.u ? 1 : 0) - (inp.d ? 1 : 0)) * sp * dt; S.y += free; }
      let hgt = S.x * ux + S.y * uy;
      if (hgt <= -ext + 0.01) { S.ground = true; if (S.v < 0) S.v = 0; }
      if (S.ground && jump) { S.v = JUMP; S.ground = false; }
      if (!S.ground) {
        if (S.v > 40 && !jump) S.v = 40;
        S.v -= (S.v > 0 ? GUP : GDN) * dt;
        hgt += S.v * dt;
        if (hgt <= -ext) { hgt = -ext; S.v = 0; S.ground = true; }
        if (hgt >= ext) { hgt = ext; if (S.v > 0) S.v = 0; }
      }
      if (ux === 0) S.y = hgt * uy; else S.x = hgt * ux;
    }
    S.x = clamp(S.x, -hx, hx); S.y = clamp(S.y, -hy, hy);
  }

  G.SB = { PAT, CATS, SPR, SPRG, TYCOL, EVERY, defaults, bake, Sim, soulStep, arenaAtSegs, spriteInfo, hexToRgb, mkrng, kinPos, DEG, PR };
})(typeof window !== 'undefined' ? window : globalThis);
