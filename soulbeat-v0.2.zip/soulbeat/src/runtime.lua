-- ===================== SoulBeat runtime (do not edit by hand) =====================
local DEG = math.pi / 180
local PR = 3
local sin, cos, abs, floor = math.sin, math.cos, math.abs, math.floor

local function atan2(y, x)
    if x > 0 then return math.atan(y / x) end
    if x < 0 then
        if y >= 0 then return math.atan(y / x) + math.pi end
        return math.atan(y / x) - math.pi
    end
    if y > 0 then return math.pi / 2 end
    if y < 0 then return -math.pi / 2 end
    return 0
end
local function clamp(v, a, b)
    if v < a then return a end
    if v > b then return b end
    return v
end
local function wrapPi(a)
    while a > math.pi do a = a - 2 * math.pi end
    while a < -math.pi do a = a + 2 * math.pi end
    return a
end

-- spawn rows are stored as text and parsed a chunk at a time
local S, nS, parsed, nChunks = {}, 0, 0, #SD
local function parseChunk()
    parsed = parsed + 1
    local row, n = {}, 0
    for v in string.gmatch(SD[parsed], "[^,]+") do
        n = n + 1
        row[n] = tonumber(v)
        if n == 8 then
            nS = nS + 1
            S[nS] = row
            row = {}
            n = 0
        end
    end
end

-- recorded playthrough (optional)
local RX, RY, nR = {}, {}, 0
if RP ~= nil then
    local odd = true
    for v in string.gmatch(RP.d, "[^,]+") do
        if odd then nR = nR + 1; RX[nR] = tonumber(v) else RY[nR] = tonumber(v) end
        odd = not odd
    end
end

local live, nlive = {}, 0
local si, fxi, ai = 1, 1, 0
local started, ended, skipdt = false, false, false
local tc = 0
local hint = nil
local override = false
local wasBlue = false
local sx, sy, sv, sground = 0, 0, 0, false
local lastpx, lastpy = 0, 0
local aax, aay, aaw, aah = -1, -1, -1, -1
local acolOn = false
local enemy, enemyFrame = nil, 0

local function setOverride(v)
    if override ~= v then
        override = v
        Player.SetControlOverride(v)
    end
end

local function arenaAt(t)
    while ai < #AR and AR[ai + 1].t0 <= t do ai = ai + 1 end
    if ai == 0 then return A0.x, A0.y, A0.w, A0.h end
    local s = AR[ai]
    local k = 1
    if s.t1 > s.t0 then k = clamp((t - s.t0) / (s.t1 - s.t0), 0, 1) end
    if s.e == 3 then k = 1
    elseif s.e == 1 then k = k * k * (3 - 2 * k)
    elseif s.e == 2 then local q = 1 - k; k = 1 - q * q * q end
    return s.fx + (s.tx - s.fx) * k, s.fy + (s.ty - s.fy) * k, s.fw + (s.tw - s.fw) * k, s.fh + (s.th - s.fh) * k
end

local function applyArena(x, y, w, h, force)
    if force or abs(x - aax) > 0.01 or abs(y - aay) > 0.01 or abs(w - aaw) > 0.01 or abs(h - aah) > 0.01 then
        aax, aay, aaw, aah = x, y, w, h
        Arena.MoveToAndResize(x, y, w, h, false, true)
    end
end

local function clearBullets()
    for i = 1, nlive do
        local e = live[i]
        if e.b.isactive then e.b.Remove() end
        live[i] = nil
    end
    nlive = 0
end

local function hurt()
    if Player.ishurting then return end
    if GOD and Player.hp - DMG < 1 then Player.hp = Player.maxhp end
    Player.Hurt(DMG, INV)
end

local function spawn(s, cx, cy, pax, pay)
    local k = K[s[2] + 1]
    local ox, oy = cx, cy
    if k.abs == 1 then ox, oy = 0, 0 end
    local x, y, ang = s[3], s[4], s[5] * DEG
    if k.atp == 1 then x = x + pax - ox; y = y + pay - oy end
    if k.aim == 1 then ang = ang + atan2(pay - oy - y, pax - ox - x) end
    local a0 = s[8] * DEG
    local lx, ly = x + s[7] * cos(a0), y + s[7] * sin(a0)
    local b = CreateProjectileAbs(k.spr, ox + lx, oy + ly)
    b.sprite.color = k.c
    b.sprite.alpha = 0
    nlive = nlive + 1
    live[nlive] = { b = b, k = k, t0 = s[1], x = x, y = y, ang = ang, spd = s[6], r0 = s[7], a0 = a0,
        hx = x, hy = y, lx = lx, ly = ly, head = ang, psx = -1, psy = -1, prot = -9999, pal = -1 }
end

local JUMP, GUP, GDN = 240, 480, 640
local function soulBlue(dt, w, h, g)
    local sp = 120
    if Input.Cancel > 0 then sp = 60 end
    local l, r, u, d = Input.Left > 0, Input.Right > 0, Input.Up > 0, Input.Down > 0
    local hx, hy = w / 2 - 8, h / 2 - 8
    local ux, uy, jump = 0, 1, u
    if g == 1 then uy = -1; jump = d
    elseif g == 2 then ux = 1; uy = 0; jump = r
    elseif g == 3 then ux = -1; uy = 0; jump = l end
    local ext = hy
    if ux ~= 0 then ext = hx end
    if ux == 0 then
        if r then sx = sx + sp * dt end
        if l then sx = sx - sp * dt end
    else
        if u then sy = sy + sp * dt end
        if d then sy = sy - sp * dt end
    end
    local hgt = sx * ux + sy * uy
    if hgt <= -ext + 0.01 then
        sground = true
        if sv < 0 then sv = 0 end
    end
    if sground and jump then sv = JUMP; sground = false end
    if not sground then
        if sv > 40 and not jump then sv = 40 end
        if sv > 0 then sv = sv - GUP * dt else sv = sv - GDN * dt end
        hgt = hgt + sv * dt
        if hgt <= -ext then hgt = -ext; sv = 0; sground = true end
        if hgt >= ext then hgt = ext; if sv > 0 then sv = 0 end end
    end
    if ux == 0 then sy = hgt * uy else sx = hgt * ux end
    sx = clamp(sx, -hx, hx)
    sy = clamp(sy, -hy, hy)
end

local function Start()
    started = true
    ended = false
    tc = 0
    skipdt = true
    si, fxi, ai = 1, 1, 0
    if hint ~= nil then
        if hint.isactive then hint.Remove() end
        hint = nil
    end
    if HASMUSIC then Audio.LoadFile("ub_music") end
end

local function Finish()
    clearBullets()
    if acolOn then
        acolOn = false
        pcall(function() Arena.outerColor = { 1, 1, 1, 1 }; Arena.innerColor = { 0, 0, 0, 1 } end)
    end
    if ENDACT == "loop" then
        Start()
    elseif ENDACT == "done" then
        if enemy ~= nil then enemy.Remove(); enemy = nil end
        Audio.Stop()
        ended = true
        State("DONE")
    else
        Audio.Stop()
        ended = true
    end
end

-- enemy picture / animation above the arena (optional)
local function placeEnemy(t, ay, ah)
    if EN == nil then return end
    if enemy == nil then
        enemy = CreateSprite("ub/enemy/1", "BelowArena")
        enemy.Scale(EN.s, EN.s)
        enemyFrame = 1
    end
    if EN.n > 1 then
        local f = floor(t * EN.fps) % EN.n + 1
        if f ~= enemyFrame then
            enemyFrame = f
            enemy.Set("ub/enemy/" .. f)
        end
    end
    enemy.MoveToAbs(320 + EN.x, ay + ah + 11 + EN.y + EN.h * EN.s / 2)
end

-- initial placement
applyArena(A0.x, A0.y, A0.w, A0.h, true)
placeEnemy(0, A0.y, A0.h)
Player.MoveToAbs(A0.x, A0.y + 5 + A0.h / 2, true)
lastpx, lastpy = Player.absx, Player.absy
if WAITZ then
    hint = CreateProjectileAbs("ub/pressz", 320, 300)
end

function OnHit(bullet)
    -- collisions are handled below, identically to the editor preview
end

function Update()
    if not started then
        if (not WAITZ) or Input.Confirm == 1 then Start() else return end
    end
    if ended then return end

    local dt = Time.dt
    if skipdt then skipdt = false else tc = tc + dt end
    if HASMUSIC then
        local pt = Audio.playtime
        if abs(pt - tc) > 0.07 and not (pt < tc - 2 and tc > DUR - 3) then tc = pt end
    end
    if tc >= DUR then
        Finish()
        return
    end
    local t = tc + SYNC
    if t < 0 then t = 0 end

    -- arena
    local ax, ay, aw, ah = arenaAt(t)
    applyArena(ax, ay, aw, ah, false)
    placeEnemy(t, ay, ah)
    local cx, cy = ax, ay + 5 + ah / 2

    local col = nil
    for i = 1, #AC do
        if AC[i].t0 <= t and t < AC[i].t1 then col = AC[i] end
    end
    if col ~= nil then
        acolOn = true
        pcall(function() Arena.outerColor = { col.o[1], col.o[2], col.o[3], 1 }; Arena.innerColor = { col.i[1], col.i[2], col.i[3], 1 } end)
    elseif acolOn then
        acolOn = false
        pcall(function() Arena.outerColor = { 1, 1, 1, 1 }; Arena.innerColor = { 0, 0, 0, 1 } end)
    end

    -- soul
    local blue = nil
    for i = 1, #SO do
        if SO[i].t0 <= t and t < SO[i].t1 then blue = SO[i] end
    end
    local hx, hy = aw / 2 - 8, ah / 2 - 8
    if nR > 0 then
        setOverride(true)
        local f = t * RP.hz + 1
        local i0 = floor(f)
        if i0 < 1 then i0 = 1 end
        if i0 > nR then i0 = nR end
        local i1 = i0 + 1
        if i1 > nR then i1 = nR end
        local fr = clamp(f - i0, 0, 1)
        local rx = RX[i0] + (RX[i1] - RX[i0]) * fr
        local ry = RY[i0] + (RY[i1] - RY[i0]) * fr
        Player.MoveToAbs(cx + clamp(rx, -hx, hx), cy + clamp(ry, -hy, hy), true)
        if (blue ~= nil) ~= wasBlue then
            wasBlue = (blue ~= nil)
            if wasBlue then Player.sprite.color = { 0, 0.24, 1 } else Player.sprite.color = { 1, 0, 0 } end
        end
    elseif blue ~= nil then
        setOverride(true)
        if not wasBlue then
            wasBlue = true
            sx, sy, sv, sground = Player.absx - cx, Player.absy - cy, 0, false
            Player.sprite.color = { 0, 0.24, 1 }
        end
        soulBlue(dt, aw, ah, blue.g)
        Player.MoveToAbs(cx + sx, cy + sy, true)
    else
        if wasBlue then
            wasBlue = false
            Player.sprite.color = { 1, 0, 0 }
        end
        setOverride(false)
        local rx, ry = Player.absx - cx, Player.absy - cy
        if rx < -hx or rx > hx or ry < -hy or ry > hy then
            Player.MoveToAbs(cx + clamp(rx, -hx, hx), cy + clamp(ry, -hy, hy), true)
        end
    end
    local pax, pay = Player.absx, Player.absy
    local moving = abs(pax - lastpx) > 0.01 or abs(pay - lastpy) > 0.01
    lastpx, lastpy = pax, pay

    -- timed events
    while fxi <= #FX and FX[fxi].t <= t do
        local f = FX[fxi]
        fxi = fxi + 1
        if f.f == 1 then
            pcall(function() Misc.ShakeScreen(f.a, f.b, true) end)
        elseif f.f == 2 then
            pcall(function() Audio.PlaySound(f.s, f.b) end)
        end
    end

    -- spawns
    while parsed < nChunks and ST[parsed + 1] <= t + 2 do parseChunk() end
    while si <= nS and S[si][1] <= t do
        spawn(S[si], cx, cy, pax, pay)
        si = si + 1
    end

    -- bullets
    local n = nlive
    while n >= 1 do
        local e = live[n]
        local k = e.k
        local age = t - e.t0
        if age >= k.life or e.dead then
            if e.b.isactive then e.b.Remove() end
            live[n] = live[nlive]
            live[nlive] = nil
            nlive = nlive - 1
        else
            local tau = 0
            if age > k.warn then tau = age - k.warn end
            local ox, oy = cx, cy
            if k.abs == 1 then ox, oy = 0, 0 end
            local px, py
            if k.home > 0 then
                if tau > 0 then
                    local des = atan2(pay - oy - e.hy, pax - ox - e.hx)
                    local d = wrapPi(des - e.ang)
                    local lim = k.home * DEG * dt
                    e.ang = e.ang + clamp(d, -lim, lim)
                    local v = e.spd + k.acc * tau
                    if v < 0 then v = 0 end
                    e.hx = e.hx + cos(e.ang) * v * dt
                    e.hy = e.hy + sin(e.ang) * v * dt
                end
                px, py = e.hx, e.hy
            else
                local d = e.spd * tau + 0.5 * k.acc * tau * tau
                if k.acc < 0 and e.spd > 0 then
                    local ts = e.spd / -k.acc
                    if tau > ts then d = e.spd * ts + 0.5 * k.acc * ts * ts end
                end
                local wv = 0
                if k.amp ~= 0 then wv = k.amp * sin(2 * math.pi * k.frq * tau) end
                local ca, sa = cos(e.ang), sin(e.ang)
                px = e.x + ca * d - sa * wv + 0.5 * k.gx * tau * tau
                py = e.y + sa * d + ca * wv + 0.5 * k.gy * tau * tau
                local r = e.r0 + k.rv * tau
                if k.ra ~= 0 then r = r + k.ra * sin(2 * math.pi * k.rf * tau) end
                if r ~= 0 then
                    local a = e.a0 + k.w * DEG * tau
                    px = px + r * cos(a)
                    py = py + r * sin(a)
                end
            end
            local ddx, ddy = px - e.lx, py - e.ly
            if ddx * ddx + ddy * ddy > 0.0001 then e.head = atan2(ddy, ddx) end
            e.lx, e.ly = px, py
            local X, Y = px + ox, py + oy
            local rot = k.rot0 + k.spin * age
            if k.face == 1 then rot = rot + e.head / DEG elseif k.face == 2 then rot = rot + e.ang / DEG end
            local sc = k.s0
            if k.gt > 0 then
                local q = age / k.gt
                if q > 1 then q = 1 end
                sc = k.s0 + (k.s1 - k.s0) * q
            end
            local al = k.a
            if k.fi > 0 then
                local q = age / k.fi
                if q < 1 then al = al * q end
            end
            if k.fo > 0 then
                local q = (k.life - age) / k.fo
                if q < 1 then al = al * q end
            end
            local inWarn = age < k.warn
            if inWarn then al = al * k.wa end
            local bf = 1
            if k.bm == 1 then
                if inWarn then
                    bf = 1 / k.hh
                else
                    bf = clamp(math.min((age - k.warn) / 0.06, (k.life - age) / 0.1), 0, 1)
                end
            end

            local b = e.b
            b.MoveToAbs(X, Y)
            local vsx, vsy = sc * k.sx, sc * k.sy * bf
            if vsx ~= e.psx or vsy ~= e.psy then
                e.psx, e.psy = vsx, vsy
                b.sprite.Scale(vsx, vsy)
            end
            if rot ~= e.prot then
                e.prot = rot
                b.sprite.rotation = rot % 360
            end
            if al ~= e.pal then
                e.pal = al
                b.sprite.alpha = al
            end

            if (not inWarn) and k.ty ~= 4 and al > 0.3 and bf > 0.5 then
                local dx, dy = pax - X, pay - Y
                local hit = false
                if k.sh == 0 then
                    local rr = k.hr * sc + PR
                    hit = dx * dx + dy * dy < rr * rr
                else
                    local r = rot * DEG
                    local cr, sr = cos(r), sin(r)
                    local lx, ly = dx * cr + dy * sr, -dx * sr + dy * cr
                    hit = abs(lx) < k.hw * sc + PR and abs(ly) < k.hh * sc * bf + PR
                end
                if hit then
                    if k.ty == 0 then hurt()
                    elseif k.ty == 1 then if moving then hurt() end
                    elseif k.ty == 2 then if not moving then hurt() end
                    elseif k.ty == 3 then
                        Player.Heal(1)
                        e.dead = true
                    end
                end
            end
        end
        n = n - 1
    end
end

function EndingWave()
    setOverride(false)
end
