// ===== SoulBeat app, part 1: state, sprites, audio, preview =====
'use strict';
const $ = (id) => document.getElementById(id);
const { PAT, CATS, SPR, DEG } = SB;
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
const clampN = (v, a, b) => (v < a ? a : v > b ? b : v);
// ---------- i18n: English is the source language, Russian comes from the dictionary ----------
let lang = 'en';
try { lang = localStorage.getItem('sb_lang') === 'ru' ? 'ru' : 'en'; } catch (e) { }
const RU = {};
for (const [a, b] of RU_AUTO) RU[a] = b;
Object.assign(RU, RU_EXTRA);
function tr(s) { return lang === 'ru' && RU[s] !== undefined ? RU[s] : s; }
function applyStatic() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-t]').forEach((e) => { e.textContent = tr(e.dataset.t); });
  document.querySelectorAll('[data-th]').forEach((e) => { e.innerHTML = tr(e.dataset.th); });
  document.querySelectorAll('[data-tt]').forEach((e) => { e.title = tr(e.dataset.tt); });
}
const VERSION = '0.2';
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// param visibility rules
(function () {
  const show = (t, k, f) => { const d = PAT[t].params.find((x) => x.k === k); if (d) d.show = f; };
  show('aimed', 'pos', (p) => p.from === 'pos');
  show('laser', 'pos', (p) => p.orient === 'free');
  show('laser', 'angle', (p) => p.orient === 'free');
  show('laser', 'place', (p) => p.orient === 'h' || p.orient === 'v' || p.orient === 'alt');
  show('bones', 'gap', (p) => p.mode === 'corr');
  show('bones', 'hgt', (p) => p.mode !== 'corr' && p.mode !== 'rand');
  show('mines', 'count', (p) => p.place !== 'grid');
  show('shake', 'lenb', (p) => p.every !== '0');
  show('object', 'wfrq', (p) => p.wamp > 0);
})();

function newProject() {
  return {
    app: 'soulbeat', ver: 1, name: tr('My fight'), bpm: 120, offset: 0, duration: 32, seed: 1, nextId: 1, nextAsset: 1,
    settings: {
      playerName: 'CHARA', lv: 1, damage: 3, inv: 1.2, god: true, hideUI: false, waitZ: true, endAction: 'stay', sync: 0,
      bg: 'black', bgAsset: '', monsterAsset: '', monsterX: 0, monsterY: 0, monsterScale: 1, monsterName: 'SoulBeat', encText: '* ...',
      arena: { x: 320, y: 90, w: 155, h: 130 }, cyfReplay: false,
    },
    assets: [], clips: [], replay: null,
  };
}
function demoProject() {
  const p = newProject(); p.name = tr('Demo');
  const add = (type, bt, bd, lane, over) => p.clips.push({ id: p.nextId++, type, lane, t: bt * 0.5, d: bd * 0.5, p: Object.assign(SB.defaults(type), over || {}) });
  add('ring', 0, 8, 0, {});
  add('flash', 0, 1, 4, { alpha: 0.5 });
  add('laser', 8, 8, 1, {});
  add('rain', 8, 8, 0, { speed: 110, every: '0.5' });
  add('arena', 16, 2, 3, { w: 240, h: 100 });
  add('spiral', 16, 16, 0, { count: 4, twist: 9, btype: '0', spr: 'star', size: 0.5, speed: 80 });
  add('shake', 16, 1, 4, { power: 6 });
  add('aimed', 24, 8, 1, { warnb: 0.5, count: 3 });
  add('arena', 32, 2, 3, { w: 155, h: 130 });
  add('orbit', 32, 16, 0, { arms: 4, speed: 80 });
  add('cage', 34, 12, 1, { every: '4', closeb: 3 });
  add('slash', 40, 8, 2, { lines: 2 });
  add('soul', 48, 16, 2, {});
  add('bones', 48, 16, 0, { mode: 'alt', hgt: 35, every: '2', speed: 110 });
  add('bomb', 56, 8, 1, { every: '4', burst: 6, spr: 'sparkle', size: 0.5 });
  add('acol', 48, 16, 4, { col: '#3a86ff' });
  return p;
}

let proj = demoProject();
let B = null, sim = null;
let curT = 0, playing = false;
const sel = new Set();
let armed = 'ring';
let loopSel = false, recTake = false, recording = false, metro = false, lastBeatI = -1;
const animFr = {};   // asset id -> { frames: [canvas], fps } for GIF / video enemies
const music = { buf: null, name: '', blob: null, peaks: null };
const sndBuf = {};   // asset id -> AudioBuffer
const imgEl = {};    // asset id -> canvas
let actx = null, master = null, musicSrc = null, clockBase = 0, recDest = null;

const beatLen = () => 60 / (proj.bpm || 120);
function clipById(id) { return proj.clips.find((c) => c.id === id); }
function oneSel() { return sel.size === 1 ? clipById([...sel][0]) : null; }

// ---------- undo ----------
const undoSt = [], redoSt = [];
const snap0 = () => JSON.stringify({ clips: proj.clips, settings: proj.settings, bpm: proj.bpm, offset: proj.offset, duration: proj.duration, name: proj.name });
let lastUndoAt = 0, lastUndoKey = '';
function pushUndo(key) {
  const now = performance.now();
  if (key && key === lastUndoKey && now - lastUndoAt < 900) { lastUndoAt = now; return; }
  lastUndoKey = key || ''; lastUndoAt = now;
  undoSt.push(snap0()); if (undoSt.length > 120) undoSt.shift(); redoSt.length = 0;
}
function applySnap(s) { const o = JSON.parse(s); Object.assign(proj, o); for (const id of [...sel]) if (!clipById(id)) sel.delete(id); changed(true); syncTop(); }
function undo() { if (!undoSt.length) return; redoSt.push(snap0()); applySnap(undoSt.pop()); }
function redo() { if (!redoSt.length) return; undoSt.push(snap0()); applySnap(redoSt.pop()); }

// ---------- sprites ----------
const sprCv = {};
function raster(w, h, fn) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const x = c.getContext('2d'), d = x.createImageData(w, h);
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
    const on = fn(i + 0.5, j + 0.5), o = (j * w + i) * 4;
    d.data[o] = d.data[o + 1] = d.data[o + 2] = 255; d.data[o + 3] = on ? 255 : 0;
  }
  x.putImageData(d, 0, 0); return c;
}
function inPoly(px, py, pts) {
  let ins = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const a = pts[i], b = pts[j];
    if ((a[1] > py) !== (b[1] > py) && px < ((b[0] - a[0]) * (py - a[1])) / (b[1] - a[1]) + a[0]) ins = !ins;
  }
  return ins;
}
function heartFn(s) { return (x, y) => { const u = (x - s / 2) / (s / 2) * 1.25, v = -(y - s * 0.47) / (s / 2) * 1.25; const q = u * u + v * v - 1; return q * q * q - u * u * v * v * v < 0; }; }
function buildSprites() {
  const circ = (s, r) => raster(s, s, (x, y) => (x - s / 2) ** 2 + (y - s / 2) ** 2 <= r * r);
  sprCv.bullet = circ(16, 7.4); sprCv.dot = circ(8, 3.6); sprCv.big = circ(32, 14.5);
  sprCv.ring = raster(24, 24, (x, y) => { const d = Math.hypot(x - 12, y - 12); return d <= 11.5 && d >= 8; });
  const star = []; for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 5 : 11.5; star.push([12 + Math.cos(a) * r, 12.5 + Math.sin(a) * r]); }
  sprCv.star = raster(24, 24, (x, y) => inPoly(x, y, star));
  sprCv.diamond = raster(16, 16, (x, y) => Math.abs(x - 8) + Math.abs(y - 8) <= 7.5);
  sprCv.knife = raster(28, 10, (x, y) => inPoly(x, y, [[0, 3], [6, 3], [6, 0], [8, 0], [8, 2], [20, 2], [28, 5], [20, 8], [8, 8], [8, 10], [6, 10], [6, 7], [0, 7]]));
  sprCv.tri = raster(16, 16, (x, y) => inPoly(x, y, [[1, 1], [15, 8], [1, 15], [5, 8]]));
  sprCv.note = raster(16, 24, (x, y) => ((x - 6) ** 2 / 30 + (y - 19) ** 2 / 17 <= 1) || (x >= 9 && x <= 11.5 && y >= 3 && y <= 19) || inPoly(x, y, [[9, 1], [16, 5], [16, 10], [11, 7], [9, 7]]));
  sprCv.heart = raster(16, 16, heartFn(16));
  sprCv.square = raster(12, 12, () => true);
  sprCv.px = raster(4, 4, () => true);
  sprCv._soul = raster(16, 16, heartFn(16));
  buildSprites2();
}
// path-drawn sprites: draw with the 2D API, then snap to hard 1-bit pixels
function ps(w, h, fn) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.fillStyle = '#fff'; fn(x);
  const d = x.getImageData(0, 0, w, h), a = d.data;
  for (let i = 0; i < a.length; i += 4) { const on = a[i + 3] >= 110; a[i] = a[i + 1] = a[i + 2] = 255; a[i + 3] = on ? 255 : 0; }
  x.putImageData(d, 0, 0); return c;
}
const poly = (x, pts) => { x.beginPath(); pts.forEach((p, i) => (i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1]))); x.closePath(); x.fill(); };
const disc = (x, cx, cy, r) => { x.beginPath(); x.arc(cx, cy, r, 0, 7); x.fill(); };
const cut = (x, fn) => { x.globalCompositeOperation = 'destination-out'; fn(); x.globalCompositeOperation = 'source-over'; };
function buildSprites2() {
  sprCv.spade = ps(24, 24, (x) => { poly(x, [[12, 0.5], [2.5, 12], [21.5, 12]]); disc(x, 7.2, 13.5, 5.6); disc(x, 16.8, 13.5, 5.6); poly(x, [[12, 13], [8, 23.5], [16, 23.5]]); });
  sprCv.scythe = ps(32, 32, (x) => { disc(x, 16, 16, 15.5); cut(x, () => disc(x, 22, 13, 13.5)); });
  sprCv.egg = ps(16, 20, (x) => { x.beginPath(); x.ellipse(8, 11, 7, 8.6, 0, 0, 7); x.fill(); cut(x, () => { x.lineWidth = 1.6; x.beginPath(); x.moveTo(1, 11); x.lineTo(4.5, 8.5); x.lineTo(8, 12); x.lineTo(11.5, 8.5); x.lineTo(15, 11); x.stroke(); }); });
  sprCv.gear = ps(24, 24, (x) => { x.translate(12, 12); for (let i = 0; i < 8; i++) { x.rotate(Math.PI / 4); x.fillRect(-2.6, -12, 5.2, 6); } disc(x, 0, 0, 8.6); cut(x, () => disc(x, 0, 0, 3.4)); });
  sprCv.bolt = ps(16, 28, (x) => poly(x, [[10, 0], [1, 15.5], [7, 15.5], [4, 28], [15, 11], [9, 11], [13.5, 0]]));
  sprCv.wing = ps(28, 20, (x) => poly(x, [[1, 18], [4, 8], [11, 2], [27, 0.5], [22.5, 5.5], [26.5, 6.5], [20.5, 10.5], [23.5, 12.5], [16.5, 15], [18.5, 18], [9, 19.5]]));
  sprCv.sparkle = ps(24, 24, (x) => { x.beginPath(); x.moveTo(12, 0); x.quadraticCurveTo(13.6, 10.4, 24, 12); x.quadraticCurveTo(13.6, 13.6, 12, 24); x.quadraticCurveTo(10.4, 13.6, 0, 12); x.quadraticCurveTo(10.4, 10.4, 12, 0); x.fill(); disc(x, 12, 12, 3.4); });
  sprCv.sword = ps(36, 12, (x) => { poly(x, [[10, 3.8], [30, 3.8], [36, 6], [30, 8.2], [10, 8.2]]); x.fillRect(8, 0, 3, 12); x.fillRect(2, 4.6, 6, 2.8); disc(x, 2.4, 6, 2.4); });
  sprCv.shield = ps(22, 26, (x) => { x.beginPath(); x.moveTo(1, 1); x.lineTo(21, 1); x.lineTo(21, 11); x.quadraticCurveTo(21, 20, 11, 25.5); x.quadraticCurveTo(1, 20, 1, 11); x.closePath(); x.fill(); cut(x, () => { x.fillRect(9.5, 5, 3, 14); x.fillRect(5, 9.5, 12, 3); }); });
  const hexP = (r) => Array.from({ length: 6 }, (_, i) => [12 + Math.cos(i * Math.PI / 3) * r, 12 + Math.sin(i * Math.PI / 3) * r]);
  sprCv.hex = ps(24, 24, (x) => { poly(x, hexP(11.8)); cut(x, () => poly(x, hexP(7))); });
  sprCv.chevron = ps(20, 20, (x) => { poly(x, [[0.5, 1], [5.5, 1], [12, 10], [5.5, 19], [0.5, 19], [7, 10]]); poly(x, [[8.5, 1], [13.5, 1], [20, 10], [13.5, 19], [8.5, 19], [15, 10]]); });
  sprCv.flame = ps(18, 26, (x) => { x.beginPath(); x.moveTo(9.5, 0); x.bezierCurveTo(10.5, 7, 18, 10, 17.2, 18); x.bezierCurveTo(16.6, 23, 13, 26, 9, 26); x.bezierCurveTo(5, 26, 1.4, 23, 0.8, 18); x.bezierCurveTo(0.4, 13.5, 3.5, 11, 4.5, 6.5); x.bezierCurveTo(6, 9.5, 8.5, 8, 9.5, 0); x.fill(); cut(x, () => { x.beginPath(); x.moveTo(9, 14.5); x.bezierCurveTo(12.5, 17.5, 12.6, 21, 9, 23.2); x.bezierCurveTo(5.4, 21, 5.5, 17.5, 9, 14.5); x.fill(); }); });
  sprCv.skull = ps(22, 24, (x) => { disc(x, 11, 10, 10); x.fillRect(5.5, 14, 11, 9.5); cut(x, () => { disc(x, 7, 10, 2.9); disc(x, 15, 10, 2.9); poly(x, [[11, 13], [9.4, 16.4], [12.6, 16.4]]); x.fillRect(8.4, 20, 1.2, 3.6); x.fillRect(10.4, 20, 1.2, 3.6); x.fillRect(12.4, 20, 1.2, 3.6); }); });
  sprCv.leaf = ps(26, 14, (x) => { x.fillRect(0, 6.2, 5, 1.6); x.beginPath(); x.moveTo(3, 7); x.quadraticCurveTo(11, -4, 26, 7); x.quadraticCurveTo(11, 18, 3, 7); x.fill(); cut(x, () => { x.lineWidth = 1.1; x.beginPath(); x.moveTo(6, 7); x.lineTo(21, 7); x.moveTo(10, 7); x.lineTo(13, 3.5); x.moveTo(10, 7); x.lineTo(13, 10.5); x.moveTo(15, 7); x.lineTo(18, 4.5); x.moveTo(15, 7); x.lineTo(18, 9.5); x.stroke(); }); });
  sprCv.mushroom = ps(22, 22, (x) => { x.beginPath(); x.arc(11, 11.5, 10.6, Math.PI, 0); x.closePath(); x.fill(); x.fillRect(7.5, 11, 7, 10.5); cut(x, () => { disc(x, 6.5, 7, 1.9); disc(x, 13.5, 5, 1.7); disc(x, 16.5, 9, 1.3); }); });
}
function boneCv(h) {
  return raster(10, h, (x, y) => {
    const yy = Math.min(y, h - y);
    if (yy < 5) return (x - 2.8) ** 2 + (yy - 2.8) ** 2 <= 8.2 || (x - 7.2) ** 2 + (yy - 2.8) ** 2 <= 8.2 || (x >= 3 && x <= 7 && yy > 2);
    return x >= 3 && x <= 7;
  });
}
function getSprite(name) {
  if (sprCv[name]) return sprCv[name];
  if (name && name.indexOf('bone_') === 0) return (sprCv[name] = boneCv(+name.slice(5)));
  if (imgEl[name]) return imgEl[name];
  return sprCv.bullet;
}
const tintCache = new Map();
function tinted(name, c) {
  if (c[0] === 1 && c[1] === 1 && c[2] === 1) return getSprite(name);
  const key = name + '|' + c.join(',');
  let t = tintCache.get(key);
  if (!t) {
    const s = getSprite(name); t = document.createElement('canvas'); t.width = s.width; t.height = s.height;
    const x = t.getContext('2d'); x.drawImage(s, 0, 0); x.globalCompositeOperation = 'multiply';
    x.fillStyle = `rgb(${c[0] * 255 | 0},${c[1] * 255 | 0},${c[2] * 255 | 0})`; x.fillRect(0, 0, t.width, t.height);
    x.globalCompositeOperation = 'destination-in'; x.drawImage(s, 0, 0);
    if (tintCache.size > 400) tintCache.clear();
    tintCache.set(key, t);
  }
  return t;
}
// ---------- animated enemies: GIF / animated WebP / APNG / video -> list of frames ----------
const ANIM_MAX = 240, ANIM_SIDE = 256, VIDEO_FPS = 12, VIDEO_SEC = 20;
const KEYCOL = { green: [0, 255, 0, 110, 170], blue: [0, 0, 255, 110, 170], magenta: [255, 0, 255, 110, 170], black: [0, 0, 0, 45, 90], white: [255, 255, 255, 45, 90] };
function keyOut(c, key) {
  const k = KEYCOL[key]; if (!k) return;
  const x = c.getContext('2d'), d = x.getImageData(0, 0, c.width, c.height), a = d.data;
  for (let i = 0; i < a.length; i += 4) {
    const dr = a[i] - k[0], dg = a[i + 1] - k[1], db = a[i + 2] - k[2], dist = Math.sqrt(dr * dr + dg * dg + db * db);
    if (dist < k[3]) a[i + 3] = 0; else if (dist < k[4]) a[i + 3] = a[i + 3] * (dist - k[3]) / (k[4] - k[3]);
  }
  x.putImageData(d, 0, 0);
}
function frameCanvas(src, sw, sh, key) {
  const k = Math.min(1, ANIM_SIDE / Math.max(sw, sh)), w = Math.max(1, Math.round(sw * k)), h = Math.max(1, Math.round(sh * k));
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  c.getContext('2d', { willReadFrequently: !!key }).drawImage(src, 0, 0, w, h);
  if (key) keyOut(c, key);
  return c;
}
async function isAnimatedImage(blob, mime) {
  if (!window.ImageDecoder || !/gif|webp|png/.test(mime)) return false;
  try { const dec = new ImageDecoder({ data: await blob.arrayBuffer(), type: mime }); await dec.tracks.ready; await dec.completed; const n = dec.tracks.selectedTrack.frameCount; dec.close(); return n > 1; } catch (e) { return false; }
}
async function decodeAnim(a, onProgress) {
  const blob = await (await fetch(a.data)).blob(), frames = [];
  let fps = VIDEO_FPS;
  if (a.mime.startsWith('video')) {
    const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.preload = 'auto';
    const url = URL.createObjectURL(blob); v.src = url;
    await new Promise((res, rej) => { v.onloadeddata = res; v.onerror = () => rej(new Error('video')); });
    const dur = isFinite(v.duration) && v.duration > 0 ? v.duration : 10;
    const n = Math.max(1, Math.min(ANIM_MAX, Math.floor(Math.min(dur, VIDEO_SEC) * fps)));
    for (let i = 0; i < n; i++) {
      await new Promise((res) => { const tm = setTimeout(res, 3000); v.onseeked = () => { clearTimeout(tm); res(); }; v.currentTime = Math.min(dur - 0.01, i / fps + 0.002); });
      frames.push(frameCanvas(v, v.videoWidth, v.videoHeight, a.key));
      if (onProgress && i % 12 === 0) onProgress(i / n);
    }
    URL.revokeObjectURL(url);
  } else {
    const dec = new ImageDecoder({ data: await blob.arrayBuffer(), type: a.mime }); await dec.tracks.ready; await dec.completed;
    const n = Math.min(ANIM_MAX, dec.tracks.selectedTrack.frameCount); let total = 0;
    for (let i = 0; i < n; i++) {
      const im = (await dec.decode({ frameIndex: i })).image;
      frames.push(frameCanvas(im, im.displayWidth, im.displayHeight, a.key)); total += im.duration || 100000; im.close();
      if (onProgress && i % 12 === 0) onProgress(i / n);
    }
    dec.close(); fps = clampN(n / (total / 1e6), 1, 30);
  }
  if (!frames.length) throw new Error('no frames');
  animFr[a.id] = { frames, fps: Math.round(fps * 100) / 100 };
  a.w = frames[0].width; a.h = frames[0].height; a.n = frames.length;
  const th = document.createElement('canvas'), tk = Math.min(1, 72 / Math.max(a.w, a.h)); th.width = Math.max(1, Math.round(a.w * tk)); th.height = Math.max(1, Math.round(a.h * tk));
  th.getContext('2d').drawImage(frames[0], 0, 0, th.width, th.height); a.thumb = th.toDataURL('image/png');
}
// what stands above the arena right now (null = nothing, and nothing is drawn or shifted)
function enemyGfx() {
  const id = proj.settings.monsterAsset; if (!id) return null;
  if (animFr[id]) return animFr[id];
  if (imgEl[id]) return { frames: [imgEl[id]], fps: 1 };
  return null;
}
function loadAssetMedia(a) {
  if (a.kind === 'anim') return decodeAnim(a).catch(() => { });
  if (a.kind === 'image') {
    return new Promise((res) => { const im = new Image(); im.onload = () => { const c = document.createElement('canvas'); c.width = im.width; c.height = im.height; c.getContext('2d').drawImage(im, 0, 0); imgEl[a.id] = c; tintCache.clear(); res(); }; im.onerror = () => res(); im.src = a.data; });
  }
  return fetch(a.data).then((r) => r.arrayBuffer()).then((ab) => ensureAudio().decodeAudioData(ab)).then((b) => { sndBuf[a.id] = b; }).catch(() => { });
}

// ---------- audio ----------
function ensureAudio() {
  if (!actx) { actx = new (window.AudioContext || window.webkitAudioContext)(); master = actx.createGain(); master.connect(actx.destination); }
  return actx;
}
function beep(freq, dur, type, vol) {
  if (!actx || actx.state !== 'running') return;
  const o = actx.createOscillator(), g = actx.createGain();
  o.type = type || 'square'; o.frequency.value = freq; g.gain.value = vol || 0.08;
  g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + dur);
  o.connect(g); g.connect(master); o.start(); o.stop(actx.currentTime + dur);
}
function playSnd(id, vol) {
  const b = sndBuf[id]; if (!b || !actx) return;
  const s = actx.createBufferSource(), g = actx.createGain(); s.buffer = b; g.gain.value = vol == null ? 0.65 : vol; s.connect(g); g.connect(master); s.start();
}
function clockNow() { return music.buf ? actx.currentTime - clockBase : performance.now() / 1000 - clockBase; }
function startClock(from) {
  ensureAudio(); if (actx.state === 'suspended') actx.resume();
  stopMusicSrc();
  if (music.buf) {
    clockBase = actx.currentTime + 0.03 - from;
    if (from < music.buf.duration) { musicSrc = actx.createBufferSource(); musicSrc.buffer = music.buf; musicSrc.connect(master); musicSrc.start(actx.currentTime + 0.03, Math.max(0, from)); }
  } else clockBase = performance.now() / 1000 - from;
}
function stopMusicSrc() { if (musicSrc) { try { musicSrc.stop(); } catch (e) { } musicSrc.disconnect(); musicSrc = null; } }

// ---------- player (preview) ----------
const P = { x: 320, y: 160, moving: false };
const S = { x: 0, y: 0, v: 0, ground: false };
const keys = {};
let hp = 20, inv = 0, shakeT = 0, shakeP = 0, wasBlue = false, deadMsg = 0, botDir = [0, 0];
const maxHp = () => { const l = clampN(Math.round(proj.settings.lv || 1), 1, 20); return l >= 20 ? 99 : 16 + 4 * l; };
function resetPlayer() { hp = maxHp(); inv = 0; shakeT = 0; deadMsg = 0; }
function hurtPlayer() {
  if (inv > 0) return;
  const st = proj.settings; hp -= st.damage; inv = st.inv; beep(140, 0.18, 'sawtooth', 0.12);
  if (hp <= 0) { hp = maxHp(); if (!st.god) deadMsg = 1.6; }
}
function onHit(b) {
  const ty = b.K.ty;
  if (ty === 0) hurtPlayer();
  else if (ty === 1) { if (P.moving) hurtPlayer(); }
  else if (ty === 2) { if (!P.moving) hurtPlayer(); }
  else if (ty === 3) { b.dead = true; hp = Math.min(maxHp(), hp + 1); beep(880, 0.12, 'triangle', 0.1); }
}
function onFx(f) { if (f.f === 1) { shakeT = f.a / 60; shakeP = f.b; } else if (f.f === 2) playSnd(f.s, f.b); }

const fut = { x: 0, y: 0 };
function botInput(t, A) {
  const hz = [0.07, 0.16, 0.28, 0.42, 0.6], wts = [6, 4, 2.5, 1.5, 1];
  const cx = A.x, cy = A.y + 5 + A.h / 2, hx = A.w / 2 - 8, hy = A.h / 2 - 8;
  const dirs = [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [0.71, 0.71], [-0.71, 0.71], [0.71, -0.71], [-0.71, -0.71]];
  const cost = new Float64Array(9);
  for (let h = 0; h < hz.length; h++) {
    const tf = t + hz[h];
    const pos = dirs.map((d) => [clampN(S.x + d[0] * 120 * hz[h], -hx, hx), clampN(S.y + d[1] * 120 * hz[h], -hy, hy)]);
    for (const b of sim.live) {
      const K = b.K; if (K.ty === 4 || K.ty === 3 || K.ty === 2) continue;
      const age = tf - b.t0; if (age >= K.life || age < K.warn - 0.03) continue;
      let bx, by;
      if (K.home > 0) { const v = b.spd; bx = b.hx + Math.cos(b.ang) * v * hz[h]; by = b.hy + Math.sin(b.ang) * v * hz[h]; }
      else { SB.kinPos(K, b, Math.max(0, age - K.warn), fut); bx = fut.x; by = fut.y; }
      if (K.abs) { bx -= cx; by -= cy; }
      const sc = K.gt > 0 ? K.s0 + (K.s1 - K.s0) * Math.min(1, age / K.gt) : K.s0;
      const r = b.rot * DEG, cr = Math.cos(r), sr = Math.sin(r);
      for (let i = 0; i < 9; i++) {
        const dx = pos[i][0] - bx, dy = pos[i][1] - by; let d;
        if (K.sh === 0) d = Math.hypot(dx, dy) - K.hr * sc;
        else { const lx = Math.abs(dx * cr + dy * sr) - K.hw * sc, ly = Math.abs(-dx * sr + dy * cr) - K.hh * sc; d = Math.max(lx, ly); }
        const m = 13;
        if (d < m) cost[i] += wts[h] * (m - d) * (m - d) * (d < 4 ? 6 : 1);
      }
    }
    if (h === hz.length - 1) for (let i = 0; i < 9; i++) cost[i] += 0.012 * (pos[i][0] * pos[i][0] + pos[i][1] * pos[i][1]) + (dirs[i][0] === botDir[0] && dirs[i][1] === botDir[1] ? -0.6 : 0);
  }
  let bi = 0; for (let i = 1; i < 9; i++) if (cost[i] < cost[bi] - 1e-9) bi = i;
  botDir = dirs[bi];
  return { l: botDir[0] < 0, r: botDir[0] > 0, u: botDir[1] > 0, d: botDir[1] < 0, slow: false };
}

function ctlMode() { return $('iCtl').value; }
function playerStep(t, dt) {
  const A = sim.arena(t), cx = A.x, cy = A.y + 5 + A.h / 2, m = sim.soulMode(t);
  const ox = P.x, oy = P.y;
  S.x = P.x - cx; S.y = P.y - cy;
  const mode = ctlMode();
  if (mode === 'take' && proj.replay && proj.replay.d.length >= 4) {
    const R = proj.replay, n = R.d.length / 2, f = t * R.hz, i0 = clampN(Math.floor(f), 0, n - 1), i1 = Math.min(n - 1, i0 + 1), fr = clampN(f - i0, 0, 1);
    S.x = R.d[i0 * 2] + (R.d[i1 * 2] - R.d[i0 * 2]) * fr; S.y = R.d[i0 * 2 + 1] + (R.d[i1 * 2 + 1] - R.d[i0 * 2 + 1]) * fr;
    S.x = clampN(S.x, -A.w / 2 + 8, A.w / 2 - 8); S.y = clampN(S.y, -A.h / 2 + 8, A.h / 2 - 8);
  } else {
    let inp;
    if (mode === 'me') inp = { l: keys.ArrowLeft || keys.KeyA, r: keys.ArrowRight || keys.KeyD, u: keys.ArrowUp || keys.KeyW, d: keys.ArrowDown || keys.KeyS, slow: keys.KeyX || keys.ShiftLeft || keys.ShiftRight };
    else if (m) { // autopilot in blue mode: hop when something is close
      let danger = false;
      for (const b of sim.live) if (b.K.ty === 0 && !b.warn && Math.hypot(b.X - P.x, b.Y - P.y) < 46) danger = true;
      inp = { u: danger && m.g === 0, d: danger && m.g === 1, r: danger && m.g === 2, l: danger && m.g === 3 };
    } else inp = botInput(t, A);
    if (m && !wasBlue) { S.v = 0; S.ground = false; }
    SB.soulStep(S, inp, dt, A, !!m, m ? m.g : 0);
  }
  wasBlue = !!m;
  P.x = cx + S.x; P.y = cy + S.y;
  P.moving = Math.abs(P.x - ox) > 0.01 || Math.abs(P.y - oy) > 0.01;
  if (recTake && playing) {
    if (!proj.replay) proj.replay = { hz: 30, d: [] };
    const R = proj.replay, i = Math.floor(t * R.hz);
    for (let k = R.d.length / 2; k <= i; k++) R.d.push(Math.round(S.x * 10) / 10, Math.round(S.y * 10) / 10);
    R.d[i * 2] = Math.round(S.x * 10) / 10; R.d[i * 2 + 1] = Math.round(S.y * 10) / 10;
  }
}

// ---------- preview drawing ----------
const cv = $('cv'), g = cv.getContext('2d');
const bgCol = { black: '#000', green: '#00ff00', blue: '#0000ff', magenta: '#ff00ff' };
let dragPos = null;
function draw() {
  const st = proj.settings, t = curT;
  g.setTransform(2, 0, 0, 2, 0, 0); g.imageSmoothingEnabled = false; g.globalAlpha = 1;
  if (st.bg === 'image' && imgEl[st.bgAsset]) g.drawImage(imgEl[st.bgAsset], 0, 0, 640, 480);
  else { g.fillStyle = bgCol[st.bg] || '#000'; g.fillRect(0, 0, 640, 480); }
  g.save();
  if (shakeT > 0 && playing) g.translate((Math.random() - 0.5) * 2 * shakeP * Math.min(1, shakeT * 4), (Math.random() - 0.5) * 2 * shakeP * Math.min(1, shakeT * 4));
  const A = sim.arena(t), top = 480 - (A.y + A.h + 10);
  const EG = enemyGfx();
  if (EG) {
    const m = EG.frames[EG.frames.length > 1 ? Math.floor(Math.max(0, t) * EG.fps) % EG.frames.length : 0], sc = st.monsterScale || 1;
    g.drawImage(m, 320 + (st.monsterX || 0) - m.width * sc / 2, top - 1 - (st.monsterY || 0) - m.height * sc, m.width * sc, m.height * sc);
  }
  const ac = sim.acol(t), rgb = (c) => `rgb(${c[0] * 255 | 0},${c[1] * 255 | 0},${c[2] * 255 | 0})`;
  g.fillStyle = ac ? rgb(ac.o) : '#fff'; g.fillRect(A.x - A.w / 2 - 5, top, A.w + 10, A.h + 10);
  g.fillStyle = ac ? rgb(ac.i) : '#000'; g.fillRect(A.x - A.w / 2, top + 5, A.w, A.h);
  // bullets (soul is drawn above arena, below nothing: draw soul first like CYF bullets-on-top)
  const blue = sim.soulMode(t);
  if (!(inv > 0 && Math.floor(inv * 14) % 2)) g.drawImage(tinted('_soul', blue ? [0, 0.24, 1] : [1, 0, 0]), Math.round(P.x) - 8, Math.round(480 - P.y) - 8);
  for (const b of sim.live) {
    const K = b.K; if (b.al <= 0.003) continue;
    const im = tinted(K.spr, K.c);
    g.save(); g.translate(b.X, 480 - b.Y); if (b.rot) g.rotate(-b.rot * DEG);
    g.scale(b.sc * K.sx, b.sc * K.sy * b.bf); g.globalAlpha = Math.min(1, b.al);
    g.drawImage(im, -im.width / 2, -im.height / 2); g.restore();
  }
  g.restore(); g.globalAlpha = 1;
  if (!st.hideUI) {
    g.font = 'bold 15px Consolas, monospace'; g.fillStyle = '#fff'; g.textBaseline = 'middle';
    g.fillText((st.playerName || 'CHARA').toUpperCase().slice(0, 9) + '   LV ' + clampN(Math.round(st.lv), 1, 20), 30, 410);
    g.font = 'bold 10px Consolas, monospace'; g.fillText('HP', 244, 411);
    const mh = maxHp(), bw = mh * 1.2;
    g.fillStyle = '#c00000'; g.fillRect(275, 400, bw, 20); g.fillStyle = '#ffff00'; g.fillRect(275, 400, bw * Math.max(0, hp) / mh, 20);
    g.fillStyle = '#fff'; g.font = 'bold 15px Consolas, monospace'; g.fillText(Math.max(0, hp) + ' / ' + mh, 275 + bw + 14, 410);
    const bn = ['FIGHT', 'ACT', 'ITEM', 'MERCY'], bx = [32, 185, 345, 500];
    g.strokeStyle = '#ff7f27'; g.fillStyle = '#ff7f27'; g.lineWidth = 2; g.font = 'bold 20px Consolas, monospace'; g.textAlign = 'center';
    for (let i = 0; i < 4; i++) { g.strokeRect(bx[i] + 1, 433, 108, 40); g.fillText(bn[i], bx[i] + 55, 454); }
    g.textAlign = 'left';
  }
  if (deadMsg > 0) { g.fillStyle = '#000a'; g.fillRect(0, 200, 640, 60); g.fillStyle = '#fff'; g.font = 'bold 18px Consolas, monospace'; g.textAlign = 'center'; g.fillText(tr('In the game this would be GAME OVER'), 320, 230); g.textAlign = 'left'; }
  if (recording) return;
  // editor overlays
  const c = oneSel();
  if (c && !playing) {
    const cx = A.x, cy = A.y + 5 + A.h / 2;
    if (PAT[c.type].params.some((d) => d.type === 'pos' && (!d.show || d.show(c.p)))) {
      const X = cx + c.p.x, Y = 480 - (cy + c.p.y);
      g.strokeStyle = '#ffe14d'; g.lineWidth = 1.5; g.beginPath(); g.arc(X, Y, 9, 0, 7); g.moveTo(X - 15, Y); g.lineTo(X + 15, Y); g.moveTo(X, Y - 15); g.lineTo(X, Y + 15); g.stroke();
    }
    if (c.type === 'arena') {
      g.setLineDash([5, 4]); g.strokeStyle = '#ffe14d'; g.lineWidth = 1.5;
      g.strokeRect(c.p.ax - c.p.w / 2 - 2.5, 480 - (c.p.ay + c.p.h + 7.5), c.p.w + 5, c.p.h + 5); g.setLineDash([]);
    }
  }
}

// ---------- bake + main loop ----------
let bakeTimer = 0, saveTimer = 0;
function rebake() {
  B = SB.bake(proj); sim = new SB.Sim(B); sim.seek(curT, P);
  const A = sim.arena(curT); clampSoul(A);
}
function clampSoul(A) { const cx = A.x, cy = A.y + 5 + A.h / 2; P.x = clampN(P.x, cx - A.w / 2 + 8, cx + A.w / 2 - 8); P.y = clampN(P.y, cy - A.h / 2 + 8, cy + A.h / 2 - 8); }
function changed(full) {
  clearTimeout(bakeTimer); bakeTimer = setTimeout(() => { rebake(); if (!playing) draw(); }, 25);
  clearTimeout(saveTimer); saveTimer = setTimeout(saveLocal, 700);
  if (full) { renderClips(); renderInspector(); drawTl(); }
}
function seek(t, keepPlay) {
  curT = clampN(t, 0, proj.duration);
  if (playing && !keepPlay) startClock(curT);
  if (sim) { sim.seek(curT, P); clampSoul(sim.arena(curT)); }
  shakeT = 0; updatePlayhead(); if (!playing) draw();
}
function play() {
  if (playing) return;
  if (curT >= proj.duration - 0.05) curT = 0;
  if (curT < 0.02) resetPlayer();
  playing = true; startClock(curT); sim.seek(curT, P); lastFrame = performance.now(); $('bPlay').textContent = '❚❚'; draw();
}
function pause() { if (!playing) return; playing = false; stopMusicSrc(); $('bPlay').textContent = '▶'; if (recording) stopRecording(); saveLocal(); draw(); renderInspector(); }
function toggle() { playing ? pause() : play(); }
let lastFrame = 0;
function frame() {
  requestAnimationFrame(frame);
  if (!playing || !sim) return;
  const now = performance.now(); let dt = Math.min(0.1, (now - lastFrame) / 1000); lastFrame = now;
  let t = clockNow(); if (t < 0) t = 0;
  const lc = loopSel && !recording ? oneSel() : null;
  if (lc && (t >= lc.t + lc.d + 0.4 || t < lc.t - 0.6)) { seek(Math.max(0, lc.t - 0.5)); return; }
  if (t >= proj.duration) { curT = proj.duration; pause(); updatePlayhead(); return; }
  curT = t;
  if (metro && !recording) { const bi = Math.floor((t - proj.offset) / beatLen()); if (bi !== lastBeatI && bi >= 0) { lastBeatI = bi; beep(bi % 4 === 0 ? 1760 : 1320, 0.05, 'square', 0.06); } }
  if (inv > 0) inv -= dt; if (shakeT > 0) shakeT -= dt; if (deadMsg > 0) deadMsg -= dt;
  playerStep(t, dt);
  sim.step(t, dt, P, onHit, onFx);
  draw(); updatePlayhead(true);
}
